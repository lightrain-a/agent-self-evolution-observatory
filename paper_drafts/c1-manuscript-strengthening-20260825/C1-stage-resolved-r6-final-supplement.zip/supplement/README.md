# Proxy Reward Memory Variance — R6 supplement projection

This archive preserves the frozen scientific evidence and existing-data diagnostics from the prior C1 supplement. R6 changes only the paper layer: it seals the stage-resolved manuscript, claim provenance, and page-compliant submission artifacts without changing scientific values or authorizing new experiments.

The scientific evidence files are byte-preserved from the historical supplement. The current R6 PDF/source hashes are recorded in CURRENT-PROJECTION.json; the replayable 35/35 claim audit and sensitivity audit remain repository artifacts outside this evidence archive.
