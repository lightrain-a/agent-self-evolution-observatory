# Reward Errors Become Persistent State — working-memory localization supplement

B11 is a zero-provider-call, post-hoc mechanism diagnostic over the 432 already archived B10 first-action outputs. The BrowserUse-style response schema emits `current_state.memory` before the first action; all 432 fields are recoverable (405 strict JSON, 27 narrow string recoveries). Pair-relative semantic attribution is computed with the exact cached all-MiniLM-L6-v2 encoder against the success/failure input-memory pair.

The mean branch-specific working-memory shift is 0.003347 (paired dz=0.148; post-hoc within-state permutation p=0.2052), so branch-specific internalization is not established. Common-centroid uptake is 0.02233 (post-hoc sign-flip p=0.0664), suggestive only. Working-memory branch shift correlates descriptively with first-action TV (Pearson r=0.464; Spearman rho=0.419; leave-one-out Pearson 0.358--0.515) but not terminal absolute effect (r=-0.023). Input S/F memory distance does not explain these stages monotonically.

No new provider calls, terminal rollouts, process rollouts, training, or GPU runs are added by B11. The full-paper observable provider-POST lower bound remains at least 1,915. B12 provider execution is explicitly not authorized from this post-hoc result; positive B10/B11 cells may not be selected for follow-up. Stable canonical PaperRegistry remains unchanged, and no daytime external review is triggered.

Private raw working-memory text, host paths, credentials, provider response IDs, and private content-addressed identifiers are excluded. Run `python verify_current_supplement.py` to validate the public projection.
