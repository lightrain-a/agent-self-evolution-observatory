# Agent Safety R9 supplement — r6 measurement/source-bound projection

This public supplement contains the frozen R23 control evidence, code, and the r6 post-hoc measurement-robustness diagnostic.

The original preregistration remains a private scientific object because three location fields contain internal filesystem paths. Its exact private file SHA-256 and embedded preregistration SHA are preserved in `evidence/agent-safety-r9-controlled-longitudinal-preregistration-public-r6.json`. The public projection changes only those location strings and has its own projection SHA; scientific values, episode schedules, thresholds, model/evaluator revisions, and authority flags are unchanged.

The 6/12 versus 3/12 action-trace projection is an analyst diagnostic only. The preregistered primary endpoint remains 8/12 versus 4/12. The 24-item human packet remains unlabeled and is not included in this public supplement or used by any claim.
