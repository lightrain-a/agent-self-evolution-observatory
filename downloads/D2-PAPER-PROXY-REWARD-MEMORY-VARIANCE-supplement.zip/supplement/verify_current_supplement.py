from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent/'evidence'
def L(n): return json.load(open(R/n))
f0=L('f0-write-channel.json'); f2=L('f2r1-confirmatory.json'); h=L('f2r1-heterogeneity-bootstrap.json'); s=L('strategy-slot-audit.json'); p=L('provider-failure-forensic.json')
checks=[
 f0['status']=='F0_SUPPORT_INCOMPLETE',
 f2['status']=='TERMINAL_FIXED_EVIDENCE_COMPLETE',
 h['status']=='POSTREADY_EXISTING_EVIDENCE_ANALYSIS_COMPLETE',
 s['status']=='EXISTING_EVIDENCE_ANALYSIS_COMPLETE',
 s['summary']['complete_pairs']==4,
 abs(s['summary']['mean_strategy_slot_jaccard_distance']-0.492857)<1e-9,
 s['summary']['strategy_slot_set_change_rate']==1.0,
 p['status']=='EXISTING_RECEIPT_FORENSIC_COMPLETE',
 p['summary']['provider_state_failures']==2,
 p['summary']['requested_failure_arm_calls']==6,
 p['summary']['completed_failure_arm_calls']==4,
 p['interpretation']['condition_dependent_completion_bias_excluded'] is False,
 p['ledger_get_only_recovery_recorded'] is True,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
