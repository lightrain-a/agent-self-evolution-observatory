# Proxy Reward Memory Variance — current r5 supplement projection

This supplement contains the frozen scientific evidence used by the current manuscript plus the existing-data strategy-slot and provider-failure diagnostics added during Stanford r2 repair. Old manuscript/PDF/ledger receipts are intentionally excluded because r3/r4 changed title, citations, and paper-layer metadata without changing scientific result sections. Files containing private host identifiers are also excluded.

The current manuscript remains conditional on paired completion for F0, preserves the failure-arm completion-bias caveat, and does not include a no-memory terminal arm.
