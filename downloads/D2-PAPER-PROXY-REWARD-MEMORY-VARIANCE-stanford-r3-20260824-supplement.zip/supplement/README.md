# Reward Errors Become Persistent State — baseline-aligned expansion supplement

This anonymous supplement binds the expanded evidence for **Reward Errors Become Persistent State: Write-Time Causality and Transport Boundaries in Agent Memory**.

The evidence is deliberately separated into three layers. (1) Write identification: the original four complete source pairs plus sixteen fresh outcome-balanced breadth pairs give 20/20 persistent-memory divergences. (2) Forced intervention sensitivity: the frozen 4x4 terminal swap remains a same-support replication after an initial non-pass and yields mean |delta|=0.15625, p=0.00074. (3) Realized transport: exact released all-MiniLM-L6-v2 top-1/.3 retrieval hits 8/188 held-out Shopping tasks with the original bank and 125/172 after expansion to twenty sources. On all 36 pre-outcome native-hit tasks with deterministic offline evaluators, the 288-call success/failure contrast is 0.02083 (p=0.4289); a 144-call no-memory arm gives presence effect 0.04514 (p=0.00147), below the unchanged 0.15 practical floor.

The DeepSeek-V4-Flash cross-policy line is a provider-support stop, not a scientific null: the first frozen unit returns no assistant text at both the 900-token parent and sole preregistered 2200-token repair, producing zero scientific units. The current expansion adds 498 observable provider POSTs, of which 464 are scientifically usable completions, and raises the full-paper observable lower bound to at least 1,339. No training or GPU fine-tuning is used.

Private provider response IDs, raw model text, host paths, credentials, and human-authorization files are excluded. Run `python verify_current_supplement.py` to validate the public numerical and claim-boundary contract.
