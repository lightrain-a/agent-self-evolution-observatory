# Proxy Reward Memory Variance — Stanford-R3 existing-evidence supplement

This supplement binds the frozen scientific evidence used by the current manuscript to the Stanford-targeted existing-evidence diagnostics. No new provider calls or rollouts are introduced. The revision adds operation-slot diagnostics, provider-failure provenance, finite 4x4 heterogeneity, a four-source non-monotonic write-to-terminal magnitude check, and an explicit E1-E6 experiment-program audit.

Execution accounting is stage-wise: F0 has 12 writer requests (10 complete), F0C has 32 writer requests, F1D has 96 policy calls, the non-passing initial terminal stage has 108 calls including 12 no-memory calls, and F2R1 has 256 confirmatory calls. These sum to 504 directly countable requests; the earlier F1 action-existence receipt is retained as 12 aligned paired units because the current acceptance bundle does not expose a trustworthy low-level request count for that stage.

F0 claims remain conditional on paired completion. The no-memory observations belong to non-confirmatory stages; F2R1 has no no-memory arm. The 4x4 and four-source diagnostics are descriptive and do not define a general transfer predictor.
