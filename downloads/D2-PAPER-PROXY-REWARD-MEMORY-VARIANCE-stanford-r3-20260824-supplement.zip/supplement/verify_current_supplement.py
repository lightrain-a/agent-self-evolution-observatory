from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence'
def L(n): return json.load(open(E/n))
f0=L('f0-write-channel.json'); f2=L('f2r1-confirmatory.json'); q=L('manuscript-qa.json')
o6=L('o6-final-evidence.json'); red=L('o6-full-bank-corruption-reduction.json'); r=L('stanford-r3-o6-revision-receipt.json'); fail=L('o6-stage1-failure-asset.json')
chron=L('f2r1-chronology-receipt.json'); repair=L('blind-review-repair-receipt.json'); post=L('post-repair-blind-review-validation-receipt.json'); day=L('daytime-story-revision-receipt.json'); dayc=L('daytime-story-optimization-contract.json')
o5=L('o5-manuscript-evidence-public.json')['payload']; s1=L('o6-stage1-r1-result-public.json')['payload']; s2=L('o6-stage2-result-public.json')['payload']; proj=json.load(open(ROOT/'CURRENT-PROJECTION.json'))
checks=[
 f0['summary']['paired_trajectories_complete']==4,
 abs(f2['summary']['observed_mean_absolute_success_rate_difference']-0.15625)<1e-12,
 abs(f2['summary']['permutation_p_ge_observed']-0.00074)<1e-12,
 o5['status']=='O5_FRESH_NO_MEMORY_CONTROL_COMPLETE', o5['execution_accounting']['recovery_scientifically_usable_units']==32,
 o5['execution_accounting']['old_exploratory_no_memory_calls_reused']==0,
 s1['status']=='O6_STAGE1_COMPLETE', s1['summary']['complete_provider_calls']==8, s1['summary']['stage1_gate_pass'] is True,
 abs(s1['summary']['mean_token_jaccard_distance']-0.737482)<1e-12,
 s2['status']=='O6_STAGE2_COMPLETE', s2['summary']['complete_primary_calls']==256, s2['summary']['provider_failures']==0,
 abs(s2['summary']['observed_mean_absolute_success_rate_difference']-0.140625)<1e-12,
 abs(s2['summary']['permutation_p_ge_observed']-0.00012)<1e-12, s2['summary']['gate_pass'] is False,
 o6['writer_stage']['complete_pairs']==4, o6['terminal_stage']['joint_gate_pass'] is False,
 o6['cross_writer_comparison']['same_direction_among_nonzero_both']==4, o6['cross_writer_comparison']['opposite_direction_among_nonzero_both']==2,
 o6['execution_accounting']['o6_provider_posts_observable_lower_bound']==273,
 fail['execution_concurrency_failure']['provider_post_count_observable_lower_bound']==9,
 q['status']=='PASS', q['revision']=='STANFORD-R3-DAYTIME-STORY-OPTIMIZATION-20260824', q['main_text_pages']==9, q['references_begin_page']>=q['main_text_pages'],
 q['checks']['scoped_title'] is True, q['checks']['single_chain_story'] is True, q['checks']['completion_conditioning_in_setup'] is True, q['checks']['no_research_os_stage_headings_in_main'] is True,
 q['checks']['paper_story_current_boundary'] is True, q['checks']['paper_reader_current_boundary'] is True,
 q['checks']['o5_fresh_no_memory_control'] is True, q['checks']['o6_cross_writer_boundary'] is True, q['checks']['o6_full_bank_corruption_reduction'] is True, q['checks']['f2r1_chronology_and_uniform_replication'] is True,
 chron['status']=='CHRONOLOGY_AND_UNIFORM_REPLICATION_VERIFIED', chron['relationship']['confirmatory_was_designed_after_initial_nonpass'] is True,
 chron['relationship']['same_4x4_support'] is True, chron['relationship']['source_selection_changed'] is False, chron['relationship']['future_task_selection_changed'] is False,
 chron['relationship']['effect_floor_changed'] is False, chron['relationship']['alpha_changed'] is False, len(chron['cell_comparison'])==16,
 repair['review_calls_are_scientific_evidence'] is False, repair['selected_repair']['new_scientific_provider_calls']==0, repair['selected_repair']['new_rollouts']==0, repair['selected_repair']['claim_expansion'] is False,
 post['status']=='POST_REPAIR_BLIND_REVIEW_WEAK_ACCEPT', post['post_repair_strict_review']['recommendation']=='weak_accept', post['post_repair_strict_review']['score_1_to_10']==6,
 post['post_repair_strict_review']['current_narrow_claim_evidence_sufficient'] is True, post['decision']=='FREEZE_SCIENTIFIC_EXPERIMENTS_FOR_CURRENT_NARROW_PAPER', post['review_calls_are_scientific_evidence'] is False,
 day['status']=='PAPER_ONLY_STORY_OPTIMIZATION_COMPLETE', day['current_candidate_pdf_sha256']==proj['current_pdf_sha256'], day['new_scientific_provider_calls']==0, day['new_rollouts']==0, day['scientific_claims_expanded'] is False, day['external_review_calls']==0, day['canonical_stable_registry_overwritten'] is False,
 dayc['status']=='FROZEN_PAPER_ONLY_OPTIMIZATION', dayc['new_scientific_provider_calls']==0, dayc['new_rollouts']==0, dayc['claim_expansion'] is False,
 red['status']=='STOP_FULL_BANK_CORRUPTION_MASK_INTERACTION_BY_TOP1_LABEL_INVARIANT_RETRIEVAL_REDUCTION', red['released_mechanism_facts']['default_top_k']==1,
 abs(red['released_mechanism_facts']['default_similarity_threshold']-0.3)<1e-12, red['symbolic_factorization']['multi_memory_interaction_identifiable_under_released_top1_mechanism'] is False,
 red['economy_decision']['new_provider_calls_authorized']==0, red['relationship_to_existing_evidence']['current_fixed_evidence_prompt_byte_equivalent_to_source_reasoningbank_wrapper'] is False,
 q['checks']['system_E4_robustness_boundary'] is True, q['checks']['system_E5_negative_failure'] is True, q['checks']['system_E6_efficiency_cost_scale'] is True,
 r['revision']=='STANFORD-R3-BLIND-REVIEW-PROVENANCE-REPAIR-20260824', r['latest_paper_only_repair']['new_scientific_provider_calls']==0,
 r['objections']['PROXY-O6']['revision_status']=='PARTIALLY_ADDRESSED_WITH_CROSS_WRITER_EXECUTION_AND_CORRUPTION_REDUCTION',
 r['system_paper_requirements']['experiment_program_E1_E6']['E6_efficiency_cost_scale']['evidence']['known_provider_posts_observable_lower_bound']==841,
 proj['claim_expansion'] is False, proj['o6_terminal_cross_writer_generalization_supported'] is False, proj['o6_full_bank_corruption_interaction_reduced'] is True, proj['o6_full_bank_corruption_new_provider_calls']==0,
 proj['f2r1_chronology_verified'] is True, proj['f2r1_confirmatory_after_initial_nonpass'] is True, proj['f2r1_same_4x4_support'] is True, proj['f2r1_gate_relaxed_after_initial'] is False,
 proj['blind_review_repair_new_scientific_calls']==0, proj['blind_review_repair_new_rollouts']==0,
 proj['post_repair_blind_review_recommendation']=='weak_accept', proj['post_repair_blind_review_score']==6, proj['post_repair_scientific_freeze_decision']=='FREEZE_SCIENTIFIC_EXPERIMENTS_FOR_CURRENT_NARROW_PAPER',
 proj['revision']=='stanford-r3-daytime-story-optimization-20260824', proj['title']=='Reward Errors Become Persistent State: A Controlled Intervention in Reward-Conditioned Agent Memory',
 proj['new_experiment'] is False, proj['scientific_values_changed'] is False, proj['new_provider_calls_exact']==0, proj['new_provider_calls_observable_lower_bound']==0, proj['new_scientifically_usable_provider_calls']==0,
 proj['current_revision_new_scientific_provider_calls']==0, proj['current_revision_new_rollouts']==0, proj['current_revision_external_review_calls']==0, proj['canonical_stable_registry_overwritten'] is False,
 proj['cumulative_r3_repair_provider_calls_observable_lower_bound']==337, proj['cumulative_r3_repair_scientifically_usable_provider_calls']==296, proj['cumulative_r3_repair_terminal_rollouts']==288,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
