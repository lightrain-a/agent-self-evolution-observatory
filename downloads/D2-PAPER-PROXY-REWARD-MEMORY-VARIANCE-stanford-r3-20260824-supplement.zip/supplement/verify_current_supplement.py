from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
R=ROOT/'evidence'
def L(n): return json.load(open(R/n))
f0=L('f0-write-channel.json'); f2=L('f2r1-confirmatory.json'); h=L('f2r1-heterogeneity-bootstrap.json')
s=L('strategy-slot-audit.json'); p=L('provider-failure-forensic.json')
d=L('existing-evidence-diagnostics.json'); q=L('manuscript-qa.json'); r=L('stanford-r3-revision-receipt.json')
checks=[
 f0['status']=='F0_SUPPORT_INCOMPLETE', f2['status']=='TERMINAL_FIXED_EVIDENCE_COMPLETE',
 h['status']=='POSTREADY_EXISTING_EVIDENCE_ANALYSIS_COMPLETE', s['status']=='EXISTING_EVIDENCE_ANALYSIS_COMPLETE',
 s['summary']['complete_pairs']==4, abs(s['summary']['mean_strategy_slot_jaccard_distance']-0.492857)<1e-9,
 p['summary']['provider_state_failures']==2, p['interpretation']['condition_dependent_completion_bias_excluded'] is False,
 d['status']=='EXISTING_EVIDENCE_DIAGNOSTICS_COMPLETE',
 abs(d['strategy_prompt_control']['mean_between_reward_modes_slot_distance']-0.555655)<1e-9,
 abs(d['strategy_prompt_control']['mean_within_mode_rewording_slot_distance']-0.246578)<1e-9,
 abs(d['terminal_heterogeneity']['two_way_centered_effect_decomposition']['source_future_interaction_share']-0.84058)<1e-9,
 q['status']=='PASS', q['new_provider_calls']==0, q['new_rollouts']==0, q['claim_expansion'] is False,
 r['new_provider_calls']==0, r['new_rollouts']==0, r['claim_expansion'] is False,
 r['objections']['PROXY-O3']['revision_status']=='PRESERVED_PERMANENT_CLAIM_BOUNDARY',
 r['objections']['PROXY-O5']['revision_status']=='DEFERRED_SCIENTIFIC_REOPEN_REQUIRED',
 r['objections']['PROXY-O6']['revision_status']=='DEFERRED_SCIENTIFIC_REOPEN_REQUIRED',
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
