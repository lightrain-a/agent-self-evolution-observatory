from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent
E=ROOT/'evidence'
def L(n): return json.load(open(E/n))
f0=L('f0-write-channel.json'); f2=L('f2r1-confirmatory.json'); q=L('manuscript-qa.json')
o6=L('o6-final-evidence.json'); red=L('o6-full-bank-corruption-reduction.json'); r=L('stanford-r3-o6-revision-receipt.json'); fail=L('o6-stage1-failure-asset.json')
o5=L('o5-manuscript-evidence-public.json')['payload']; s1=L('o6-stage1-r1-result-public.json')['payload']; s2=L('o6-stage2-result-public.json')['payload']; proj=json.load(open(ROOT/'CURRENT-PROJECTION.json'))
checks=[
 f0['summary']['paired_trajectories_complete']==4,
 abs(f2['summary']['observed_mean_absolute_success_rate_difference']-0.15625)<1e-12,
 abs(f2['summary']['permutation_p_ge_observed']-0.00074)<1e-12,
 o5['status']=='O5_FRESH_NO_MEMORY_CONTROL_COMPLETE', o5['execution_accounting']['recovery_scientifically_usable_units']==32,
 o5['execution_accounting']['old_exploratory_no_memory_calls_reused']==0,
 s1['status']=='O6_STAGE1_COMPLETE', s1['summary']['complete_provider_calls']==8, s1['summary']['stage1_gate_pass'] is True,
 abs(s1['summary']['mean_token_jaccard_distance']-0.737482)<1e-12,
 s2['status']=='O6_STAGE2_COMPLETE', s2['summary']['complete_primary_calls']==256, s2['summary']['provider_failures']==0,
 abs(s2['summary']['observed_mean_absolute_success_rate_difference']-0.140625)<1e-12,
 abs(s2['summary']['permutation_p_ge_observed']-0.00012)<1e-12, s2['summary']['gate_pass'] is False,
 o6['writer_stage']['complete_pairs']==4, o6['terminal_stage']['joint_gate_pass'] is False,
 o6['cross_writer_comparison']['same_direction_among_nonzero_both']==4, o6['cross_writer_comparison']['opposite_direction_among_nonzero_both']==2,
 o6['execution_accounting']['o6_provider_posts_observable_lower_bound']==273,
 fail['execution_concurrency_failure']['provider_post_count_observable_lower_bound']==9,
 q['status']=='PASS', q['main_text_pages']==9, q['references_begin_page']==10,
 q['checks']['o5_fresh_no_memory_control'] is True, q['checks']['o6_cross_writer_boundary'] is True, q['checks']['o6_full_bank_corruption_reduction'] is True,
 red['status']=='STOP_FULL_BANK_CORRUPTION_MASK_INTERACTION_BY_TOP1_LABEL_INVARIANT_RETRIEVAL_REDUCTION', red['released_mechanism_facts']['default_top_k']==1,
 abs(red['released_mechanism_facts']['default_similarity_threshold']-0.3)<1e-12, red['symbolic_factorization']['multi_memory_interaction_identifiable_under_released_top1_mechanism'] is False,
 red['economy_decision']['new_provider_calls_authorized']==0, red['relationship_to_existing_evidence']['current_fixed_evidence_prompt_byte_equivalent_to_source_reasoningbank_wrapper'] is False,
 q['checks']['system_E4_robustness_boundary'] is True, q['checks']['system_E5_negative_failure'] is True, q['checks']['system_E6_efficiency_cost_scale'] is True,
 r['objections']['PROXY-O6']['revision_status']=='PARTIALLY_ADDRESSED_WITH_CROSS_WRITER_EXECUTION_AND_CORRUPTION_REDUCTION',
 r['system_paper_requirements']['experiment_program_E1_E6']['E6_efficiency_cost_scale']['evidence']['known_provider_posts_observable_lower_bound']==841,
 proj['claim_expansion'] is False, proj['o6_terminal_cross_writer_generalization_supported'] is False, proj['o6_full_bank_corruption_interaction_reduced'] is True, proj['o6_full_bank_corruption_new_provider_calls']==0,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
