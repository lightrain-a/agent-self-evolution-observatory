from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent;E=R/'evidence'
def L(n):return json.load(open(E/n))
q=L('manuscript-qa.json');x=L('baseline-aligned-expansion-evidence.json');f=L('baseline-aligned-followup-evidence.json');r=L('baseline-followup-revision-receipt.json');p=json.load(open(R/'CURRENT-PROJECTION.json'))
b8=L('b8-raw-trajectory-result-public.json')['payload'];b9=L('b9-endpoint-headroom-result-public.json')['payload'];g=L('b8-tie-aware-geometry-public.json')['payload']
checks=[
 q['status']=='PASS',q['revision']=='ICLR-BASELINE-ALIGNED-FOLLOWUP-RAW-TRAJECTORY-ENDPOINT-20260824',sum(q['checks'].values())==len(q['checks'])==36,q['abstract_words_approx']==220,q['main_text_pages']==9,q['references_begin_page']==10,q['pdf_pages_total']==17,
 x['status']=='BASELINE_ALIGNED_EXPANSION_COMPLETE_WITH_CROSS_POLICY_SUPPORT_STOP',x['execution_accounting']['new_provider_posts']==498,x['execution_accounting']['new_scientifically_usable_provider_completions']==464,x['execution_accounting']['updated_full_paper_observable_provider_posts_lower_bound']==1339,
 f['status']=='BASELINE_FOLLOWUP_COMPLETE_RAW_TRAJECTORY_AND_ENDPOINT_DIAGNOSTIC',f['execution_accounting']['followup_new_provider_posts']==144,f['execution_accounting']['baseline_program_provider_posts_total']==642,f['execution_accounting']['baseline_program_scientifically_usable_completions_total']==608,f['execution_accounting']['baseline_program_scientifically_usable_terminal_rollouts_total']==576,f['execution_accounting']['full_paper_observable_provider_posts_lower_bound_after_followup']==1483,
 b8['status']=='B8_EXECUTION_COMPLETE',b8['summary']['provider_calls_complete']==144,b8['summary']['provider_failures']==0,abs(b8['summary']['observed_mean_absolute_rewrite_vs_raw_effect']-.045139)<1e-12,abs(b8['summary']['three_arm_permutation_p_ge_observed']-.00775)<1e-12,b8['summary']['primary_gate_pass'] is False,
 g['status']=='DERIVED_GEOMETRY_COMPLETE_ZERO_PROVIDER_CALLS',g['exact_rate_equalities']['all_four_equal_tasks']==31,g['runner_secondary_field_disposition']['use_in_manuscript'] is False,
 b9['status']=='B9_DIAGNOSTIC_COMPLETE',b9['provider_calls']==0,abs(b9['summary_all_36']['mean_absolute_success_failure_partial_difference']-.019511)<1e-12,abs(b9['summary_multi_reference_16']['mean_absolute_success_failure_partial_difference']-.028274)<1e-12,b9['headroom']['binary_joint_floor_cells']==18,b9['headroom']['partial_joint_floor_cells']==10,
 r['status']=='BASELINE_FOLLOWUP_INTEGRATED_QA_PASS',r['external_review_calls_current_followup']==0,r['canonical_stable_registry_overwritten'] is False,
 p['revision']=='iclr-baseline-followup-raw-trajectory-endpoint-20260824',p['claim_expansion'] is False,p['raw_trajectory_gate_pass'] is False,abs(p['raw_trajectory_rewrite_effect']-.045139)<1e-12,abs(p['partial_reference_success_failure_all']-.019511)<1e-12,p['partial_reference_confirmatory_gate'] is None,p['full_paper_observable_provider_posts_lower_bound']==1483,p['cross_policy_status']=='SUPPORT_STOP_ZERO_SCIENTIFIC_UNITS',p['canonical_stable_registry_overwritten'] is False,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)});sys.exit(0 if all(checks) else 1)
