# Reward Errors Become Persistent State — raw-trajectory / endpoint follow-up supplement

This anonymous supplement extends, but does not overwrite, the prior baseline-aligned expansion evidence.

The follow-up adds two bounded checks on the 36-task native-retrieval support. **Raw writer-input trajectory baseline (B8):** 144/144 Doubao calls complete with zero provider failures. The preregistered mean rewrite-versus-raw effect is 0.045139 with permutation p=0.00775, below the unchanged 0.15 practical-effect floor. A tie-aware derived audit shows that 31/36 tasks have identical success-memory, failure-memory, raw-trajectory, and no-memory point estimates. **Endpoint-headroom diagnostic (B9):** zero new provider calls; fractional reference coverage re-scores 432 archived success/failure/no-memory outputs. Mean absolute S/F separation is 0.019511 overall and 0.028274 on the 16 multi-reference tasks. This metric was introduced after observing binary saturation and is diagnostic only; it does not replace the preregistered B4/B5 gate.

The prior expansion remains immutable: 498 observable provider POSTs and 464 scientifically usable completions. B8 adds 144 new scientifically usable terminal calls. Across the baseline program there are therefore 642 observable POSTs, 608 scientifically usable completions, and 576 scientifically usable terminal rollouts. The full-paper observable provider-POST lower bound is at least 1,483. No training or local GPU fine-tuning is used.

Private host paths, credentials, provider response IDs/raw text, and human-authorization files are excluded. Run `python verify_current_supplement.py` to validate the public projection.
