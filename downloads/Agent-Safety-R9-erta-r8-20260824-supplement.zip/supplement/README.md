# Agent Safety supplement — r8 evaluator-relative temporal audit

This public supplement contains the frozen R23 longitudinal evidence, the r6 source-bound measurement diagnostic, the r7 Stanford round-2 paper-only audit, and the r8 Evaluator-Robust Temporal Audit (ERTA) objects.

The original preregistration remains a private scientific object because some location fields contain internal filesystem paths. Its scientific values and exact source digest remain bound through the existing public projection. R8 does not modify completed R23 trajectories, guards, HarmBench thresholds, seeds, or task schedules.

R8 adds two public evidence objects:

- `evidence/agent-safety-erta-r8-method.json`: ERTA definitions and evaluator-robust claim gates.
- `evidence/agent-safety-erta-r8-results.json`: current-premise stability, the blinded 24-item calibration, complete two-evaluator three-arm results, event-set overlap, paired sensitivity, and task-localized disagreement. Private execution receipts are referenced only by content hashes.

The original HarmBench endpoint is preserved rather than replaced by DeepSeek or a post-hoc consensus label. The r8 result is that the current-pass premise and the updated/base/NullMemory arm ordering are evaluator-relative in this realization. The 24-item human packet remains unlabeled and is not included or used by any claim. Fresh-backbone attempts stopped at the support layer before any safety output and are not generalization evidence.

Verification:

```bash
python3 supplement/verify_public_supplement_r6.py
python3 supplement/verify_round2_r7.py
python3 supplement/verify_erta_r8.py
```
