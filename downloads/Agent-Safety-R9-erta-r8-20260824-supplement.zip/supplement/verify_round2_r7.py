from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence" / "agent-safety-r9-round2-robustness-r7.json"
R6 = ROOT / "evidence" / "agent-safety-r9-measurement-robustness-r6.json"
PREREG = ROOT / "evidence" / "agent-safety-r9-controlled-longitudinal-preregistration-public-r6.json"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exact_two_sided_all_same_direction(n: int) -> float:
    return min(1.0, 2.0 * (0.5 ** n))


def main() -> None:
    e = json.loads(EVIDENCE.read_text(encoding="utf-8"))
    r6 = json.loads(R6.read_text(encoding="utf-8"))
    prereg = json.loads(PREREG.read_text(encoding="utf-8"))
    p = e["paired_sensitivity"]["primary_preregistered_endpoint"]
    q = e["paired_sensitivity"]["posthoc_action_attempt_projection"]
    checks = {
        "paper_id": e.get("paper_id") == "AGENT-SAFETY-R9",
        "r6_measurement_hash": e["source_bindings"]["r6_measurement_robustness_sha256"] == sha(R6),
        "r6_prereg_hash": e["source_bindings"]["r6_public_preregistration_projection_sha256"] == sha(PREREG),
        "primary_counts_match_r6": (
            p["updated_branch_events"] == r6["primary_endpoint"]["updated_branch_events"] == 8
            and p["base_workflow_branch_events"] == r6["primary_endpoint"]["base_workflow_branch_events"] == 4
            and p["paired_update_only"] == r6["primary_endpoint"]["paired_update_only"] == 4
            and p["paired_control_only"] == r6["primary_endpoint"]["paired_control_only"] == 0
        ),
        "primary_exact_two_sided": math.isclose(p["exact_two_sided_mcnemar_binomial_p"], exact_two_sided_all_same_direction(4)),
        "primary_exact_one_sided": math.isclose(p["exact_one_sided_binomial_p"], 0.5 ** 4),
        "posthoc_counts_match_r6": (
            q["updated_branch_events"] == r6["posthoc_action_trace_projection"]["updated_branch_events"] == 6
            and q["base_workflow_branch_events"] == r6["posthoc_action_trace_projection"]["base_workflow_branch_events"] == 3
            and q["paired_update_only"] == r6["posthoc_action_trace_projection"]["paired_update_only"] == 3
            and q["paired_control_only"] == r6["posthoc_action_trace_projection"]["paired_control_only"] == 0
        ),
        "posthoc_exact_two_sided": math.isclose(q["exact_two_sided_mcnemar_binomial_p"], exact_two_sided_all_same_direction(3)),
        "selection_no_outcome_replacement": "No state, branch, probe, schedule, or horizon selection after outcomes." in prereg["prohibitions"],
        "human_packet_unlabeled": e["measurement_boundary"]["human_spotcheck_labeled"] is False,
        "human_packet_unused": e["measurement_boundary"]["human_spotcheck_used_by_claims"] is False,
        "threshold_sweep_not_faked": e["measurement_boundary"]["threshold_sweep_from_frozen_bytes_possible"] is False,
        "no_new_calls": e["policy"]["new_agent_calls"] == 0 and e["policy"]["new_evaluator_calls"] == 0,
        "zero_authority": all(e["policy"][k] is False for k in ("scientific_authority", "experiment_authority", "gpu_authority", "submission_authority")),
    }
    out = {"checks": checks, "passed": sum(checks.values()), "required": len(checks), "pass": all(checks.values())}
    print(json.dumps(out, sort_keys=True))
    raise SystemExit(0 if out["pass"] else 1)


if __name__ == "__main__":
    main()
