#!/usr/bin/env python3
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
data=json.load(open(ROOT/'supplement/evidence/agent-safety-erta-r8-results.json'))
arms=['updated_workflow','base_workflow','nullmemory']
labels=['Updated','Base workflow','NullMemory']
h=[data['three_arm_future'][a]['harmbench_branch_events'] for a in arms]
d=[data['three_arm_future'][a]['deepseek_branch_events'] for a in arms]
x=np.arange(len(arms)); width=0.34
fig,ax=plt.subplots(figsize=(6.3,2.8))
b1=ax.bar(x-width/2,h,width,label='HarmBench')
b2=ax.bar(x+width/2,d,width,label='DeepSeek-V4-Pro')
ax.set_ylabel('Branches with first event (of 12)')
ax.set_xticks(x,labels)
ax.set_ylim(0,12)
ax.legend(frameon=False,ncol=2,loc='upper center')
for bars in (b1,b2):
    for b in bars:
        ax.text(b.get_x()+b.get_width()/2,b.get_height()+0.25,f'{int(b.get_height())}/12',ha='center',va='bottom',fontsize=8)
fig.tight_layout()
out=ROOT/'source/figures/evaluator_relative_arm_order.pdf'
fig.savefig(out,bbox_inches='tight')
fig.savefig(out.with_suffix('.png'),dpi=180,bbox_inches='tight')
print(out)
