from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parent/'evidence'
def load(n): return json.loads((R/n).read_text())
def sha(n): return hashlib.sha256((R/n).read_bytes()).hexdigest()
def canon_without(d,key):
    c=dict(d); c.pop(key,None)
    return hashlib.sha256(json.dumps(c,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
p=load('agent-safety-r9-controlled-longitudinal-preregistration-public-r6.json')
a=load('agent-safety-r9-controlled-longitudinal-adjudication-20260821.json')
m=load('agent-safety-r9-measurement-robustness-r6.json')
checks=[
 p['projection_kind']=='PUBLIC_PATH_SANITIZED_PROJECTION',
 p['private_source_file_sha256']=='baae1bb4e3eec2764d7e12e2d727613eaed36d924735930b43f27c53bd3a77e7',
 p['private_preregistration_sha256']=='2e7ca149a56931ef02b52afceda89a35339780f09d52c262acb2d99247e434c7',
 p['public_projection_sha256']==canon_without(p,'public_projection_sha256'),
 p['scientific_values_changed'] is False,
 p['source_bindings']['future_journal_sha256']==m['source_bindings']['treatment_runtime_journal_sha256'],
 sha('agent-safety-r9-no-update-control-plan-20260821.json')==p['arms']['same_schedule_no_update']['plan_sha256'],
 sha('agent-safety-r9-fixed-probe-snapshot-plan-20260821.json')==p['arms']['fixed_probe_snapshot']['plan_sha256'],
 a['primary_same_schedule_control']['treatment_branch_events']==m['primary_endpoint']['updated_branch_events']==8,
 a['primary_same_schedule_control']['control_branch_events']==m['primary_endpoint']['base_workflow_branch_events']==4,
 a['primary_same_schedule_control']['paired_discordance']['treatment_only']==m['primary_endpoint']['paired_update_only']==4,
 a['primary_same_schedule_control']['paired_discordance']['control_only']==m['primary_endpoint']['paired_control_only']==0,
 m['posthoc_action_trace_projection']['updated_branch_events']==6,
 m['posthoc_action_trace_projection']['base_workflow_branch_events']==3,
 m['posthoc_action_trace_projection']['role'].startswith('ANALYST_DIAGNOSTIC'),
 m['human_spotcheck']['labeled'] is False and m['human_spotcheck']['used_by_any_claim'] is False,
 m['classifier_score_availability']['threshold_sweep_from_frozen_bytes_possible'] is False,
 m['policy']['new_model_calls']==m['policy']['new_classifier_calls']==m['policy']['gpu_execution']==0,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
