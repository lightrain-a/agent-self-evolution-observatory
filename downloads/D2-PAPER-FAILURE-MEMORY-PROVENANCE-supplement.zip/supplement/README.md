# Evidence supplement
The structured artifacts bind the manuscript's R4, R5, and R6 quantities to the frozen claim ledger. Run `python3 verify_submission_evidence.py` to recompute the headline consistency checks from the included summaries.
