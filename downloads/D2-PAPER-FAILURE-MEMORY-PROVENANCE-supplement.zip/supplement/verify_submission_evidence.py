from pathlib import Path
import json,sys
r=Path(__file__).resolve().parent/'evidence'
r4=json.load(open(r/'r4-terminal-swap.json'))
r5=json.load(open(r/'r5-exact-information-capacity.json'))
r6=json.load(open(r/'r6-early-action.json'))
sens=json.load(open(r/'stanford-r2-r4-threshold-sensitivity-r7.json'))
power=json.load(open(r/'prospective-power-planning-r7.json'))
l3=json.load(open(r/'l3-source-faithful-execution-contract-r7.json'))
style=json.load(open(r/'l1-operational-equivalence-stress-r7.json'))
repair=json.load(open(r/'stanford-r2-targeted-repair-r7.json'))
l2_manifest=json.load(open(r/'r5-eligibility-manifest-r8.json'))
l2_contract=json.load(open(r/'l2-reopen-contract-r8.json'))
l2_gate=json.load(open(r/'l2-analysis-gate-r8.json'))
l3_recheck=json.load(open(r/'l3-public-support-recheck-r8.json'))
l2_surface=json.load(open(r/'l2-metadata-surface-reconciliation-r8.json'))
expected_l2_ids=['21','25','26','163','165']
checks=[
    r4['execution']['requests_complete']==48,
    r4['summary']['mean_success_minus_failure_terminal_rate']==0.166667,
    r4['summary']['support_gate_pass'] is False,
    r5['maximum_possible_unique_tasks_under_frozen_contract']==5,
    r5['model_requests_executed']==0,
    r6['information_equivalence']['eligible_pairs']==23,
    r6['summary']['requests_complete']==276,
    r6['summary']['mean_success_minus_failure_reference_match']==-0.094203,
    r6['summary']['support_gate_pass'] is False,
    r6['summary']['counterevidence_gate_pass'] is False,
    all(sens['threshold_results'][t]['eligible_pairs']==4 for t in ('0.75','0.85','0.90')),
    power['target_absolute_effect']==0.15 and power['target_power']==0.8,
    [x['one_sided_independent_tasks'] for x in power['planning_scenarios']]==[11,25,44],
    l3['current_status']=='NOT_EXECUTED_SUPPORT_AND_EXPERIMENT_DEBT',
    style['r4_stronger_semantic_audit']['reviewer_a_fully_equivalent']==0,
    style['r4_stronger_semantic_audit']['reviewer_b_fully_equivalent']==1,
    style['deterministic_writer_register_audit']['r6_failure_more_failure_caution']=='23/24',
    style['scientific_interpretation']['C4_causal_sign']=='UNRESOLVED',
    repair['policy']['new_model_calls'] is False and repair['frozen_scientific_boundary']['C4_causal_sign']=='UNRESOLVED',
    l2_manifest['summary']['target_unique_tasks']==10 and l2_manifest['summary']['eligible_unique_tasks']==5,
    l2_manifest['summary']['eligible_task_ids']==expected_l2_ids,
    l2_manifest['summary']['support_gate_pass'] is False and l2_manifest['summary']['model_requests_executed']==0,
    l2_manifest['summary']['scientific_outcomes_opened'] is False,
    l2_manifest['adjudication']['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['adjudication']['historical_5_of_10_value_reproduced'] is True,
    l2_contract['support_contract']['current_support_gate_pass'] is False,
    l2_contract['current_execution_gate']['model_calls_permitted'] is False and l2_contract['current_execution_gate']['scientific_outcome_execution_permitted'] is False,
    l2_contract['current_execution_gate']['current_model_call_budget']==0 and l2_contract['current_execution_gate']['l3_transition_permitted'] is False,
    l2_contract['scientific_authority'] is False and l2_contract['experiment_authority'] is False,
    l2_gate['status']=='STOP_SUPPORT_CAPACITY_NO_EXECUTION',
    l2_gate['decision']=='KEEP_L2_UNEXECUTED_AND_DO_NOT_ADVANCE_TO_L3_EXECUTION',
    l2_gate['facts']['eligible_task_ids']==expected_l2_ids and l2_gate['facts']['model_requests_executed']==0 and l2_gate['facts']['scientific_outcomes_opened'] is False,
    l2_gate['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['source']['sha256']==l2_contract['support_contract']['source_sha256']==l2_gate['inputs']['source_sha256'],
    l3_recheck['status']=='NO_NEW_FIRST_PARTY_L3_ARTIFACT_DISCOVERED',
    l3_recheck['adjudication']['l3_support_unblocked'] is False,
    l3_recheck['adjudication']['l3_execution_authorized'] is False,
    l3_recheck['adjudication']['webarena_bridge_can_substitute_for_l3'] is False,
    l3_recheck['adjudication']['generic_reasoningbank_repo_can_substitute_for_financial_per_query_bundle'] is False,
    l3_recheck['adjudication']['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    not any(l3_recheck['authority'].values()),
    l2_surface['status']=='HISTORICAL_EXPLICIT_CUE_SURFACE_RECONCILED_NO_R5_RESCUE',
    l2_surface['historical_explicit_cue_bridge']['contract']['sha256']=='d6da08c7e57f13fe9b07951b2326b9fd400202b39e9ab039d18ee2d008c15c01',
    l2_surface['historical_explicit_cue_bridge']['result']['sha256']=='2097d4de2806a6fb576e5613c89c1a6ad3212e2f3ffe30090939a4585ab20394',
    l2_surface['historical_explicit_cue_bridge']['independent_tasks']==6 and l2_surface['historical_explicit_cue_bridge']['complete_calls']==144,
    l2_surface['historical_explicit_cue_bridge']['result_summary']['mean_success_minus_failure_terminal_rate']==0.0 and l2_surface['historical_explicit_cue_bridge']['result_summary']['permutation_p_success_greater']==1.0 and l2_surface['historical_explicit_cue_bridge']['result_summary']['permutation_p_failure_greater']==1.0,
    l2_surface['historical_explicit_cue_bridge']['result_summary']['decision']=='INCONCLUSIVE_NO_NEGATIVE_AUTHORITY' and l2_surface['historical_explicit_cue_bridge']['result_summary']['support_gate_pass'] is False and l2_surface['historical_explicit_cue_bridge']['result_summary']['counterevidence_gate_pass'] is False,
    l2_surface['historical_explicit_cue_bridge']['surface']['actionable_guidance_byte_identical_across_success_failure'] is True and l2_surface['historical_explicit_cue_bridge']['surface']['metadata_is_executor_visible'] is True and l2_surface['historical_explicit_cue_bridge']['surface']['memory_object_is_naturally_generated_reasoningbank_item'] is False,
    l2_surface['non_pooling_adjudication']['bridge_plus_r5_task_count_may_be_summed'] is False and l2_surface['non_pooling_adjudication']['bridge_effect_may_be_pooled_with_r5'] is False and l2_surface['non_pooling_adjudication']['bridge_can_rescue_r5_support_gate'] is False,
    l2_surface['frozen_r5_exact_information_l2']['eligible_unique_tasks']==5 and l2_surface['frozen_r5_exact_information_l2']['target_unique_tasks_support_floor']==10 and l2_surface['frozen_r5_exact_information_l2']['model_requests_executed']==0,
    l2_surface['power_and_support_boundary']['support_floor_is_not_power_guarantee'] is True and list(l2_surface['power_and_support_boundary']['one_sided_independent_tasks_by_task_level_sd'].values())==[11,25,44],
    l2_surface['stanford_o5_reconciliation']['disposition']=='REQUIRES_SCIENTIFIC_REOPEN' and l2_surface['stanford_o5_reconciliation']['scientific_fact'].startswith('R5 exact-information L2 itself remains unexecuted'),
    not any(l2_surface['authority'].values()),
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
