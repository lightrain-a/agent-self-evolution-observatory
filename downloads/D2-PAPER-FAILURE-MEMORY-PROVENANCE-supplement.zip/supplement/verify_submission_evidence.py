from pathlib import Path
import json,sys
r=Path(__file__).resolve().parent/'evidence'
r4=json.load(open(r/'r4-terminal-swap.json')); r5=json.load(open(r/'r5-exact-information-capacity.json')); r6=json.load(open(r/'r6-early-action.json'))
checks=[r4['execution']['requests_complete']==48,r4['summary']['mean_success_minus_failure_terminal_rate']==0.166667,r4['summary']['support_gate_pass'] is False,r5['maximum_possible_unique_tasks_under_frozen_contract']==5,r5['model_requests_executed']==0,r6['information_equivalence']['eligible_pairs']==23,r6['summary']['requests_complete']==276,r6['summary']['mean_success_minus_failure_reference_match']==-0.094203,r6['summary']['support_gate_pass'] is False,r6['summary']['counterevidence_gate_pass'] is False]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
