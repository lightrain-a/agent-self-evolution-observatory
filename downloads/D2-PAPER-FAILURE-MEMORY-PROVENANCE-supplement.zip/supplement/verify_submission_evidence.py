from pathlib import Path
import json,sys
r=Path(__file__).resolve().parent/'evidence'
r4=json.load(open(r/'r4-terminal-swap.json'))
r5=json.load(open(r/'r5-exact-information-capacity.json'))
r6=json.load(open(r/'r6-early-action.json'))
sens=json.load(open(r/'stanford-r2-r4-threshold-sensitivity-r7.json'))
power=json.load(open(r/'prospective-power-planning-r7.json'))
l3=json.load(open(r/'l3-source-faithful-execution-contract-r7.json'))
style=json.load(open(r/'l1-operational-equivalence-stress-r7.json'))
repair=json.load(open(r/'stanford-r2-targeted-repair-r7.json'))
l2_manifest=json.load(open(r/'r5-eligibility-manifest-r8.json'))
l2_contract=json.load(open(r/'l2-reopen-contract-r8.json'))
l2_gate=json.load(open(r/'l2-analysis-gate-r8.json'))
expected_l2_ids=['21','25','26','163','165']
checks=[
    r4['execution']['requests_complete']==48,
    r4['summary']['mean_success_minus_failure_terminal_rate']==0.166667,
    r4['summary']['support_gate_pass'] is False,
    r5['maximum_possible_unique_tasks_under_frozen_contract']==5,
    r5['model_requests_executed']==0,
    r6['information_equivalence']['eligible_pairs']==23,
    r6['summary']['requests_complete']==276,
    r6['summary']['mean_success_minus_failure_reference_match']==-0.094203,
    r6['summary']['support_gate_pass'] is False,
    r6['summary']['counterevidence_gate_pass'] is False,
    all(sens['threshold_results'][t]['eligible_pairs']==4 for t in ('0.75','0.85','0.90')),
    power['target_absolute_effect']==0.15 and power['target_power']==0.8,
    [x['one_sided_independent_tasks'] for x in power['planning_scenarios']]==[11,25,44],
    l3['current_status']=='NOT_EXECUTED_SUPPORT_AND_EXPERIMENT_DEBT',
    style['r4_stronger_semantic_audit']['reviewer_a_fully_equivalent']==0,
    style['r4_stronger_semantic_audit']['reviewer_b_fully_equivalent']==1,
    style['deterministic_writer_register_audit']['r6_failure_more_failure_caution']=='23/24',
    style['scientific_interpretation']['C4_causal_sign']=='UNRESOLVED',
    repair['policy']['new_model_calls'] is False and repair['frozen_scientific_boundary']['C4_causal_sign']=='UNRESOLVED',
    l2_manifest['summary']['target_unique_tasks']==10 and l2_manifest['summary']['eligible_unique_tasks']==5,
    l2_manifest['summary']['eligible_task_ids']==expected_l2_ids,
    l2_manifest['summary']['support_gate_pass'] is False and l2_manifest['summary']['model_requests_executed']==0,
    l2_manifest['summary']['scientific_outcomes_opened'] is False,
    l2_manifest['adjudication']['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['adjudication']['historical_5_of_10_value_reproduced'] is True,
    l2_contract['support_contract']['current_support_gate_pass'] is False,
    l2_contract['current_execution_gate']['model_calls_permitted'] is False and l2_contract['current_execution_gate']['scientific_outcome_execution_permitted'] is False,
    l2_contract['current_execution_gate']['current_model_call_budget']==0 and l2_contract['current_execution_gate']['l3_transition_permitted'] is False,
    l2_contract['scientific_authority'] is False and l2_contract['experiment_authority'] is False,
    l2_gate['status']=='STOP_SUPPORT_CAPACITY_NO_EXECUTION',
    l2_gate['decision']=='KEEP_L2_UNEXECUTED_AND_DO_NOT_ADVANCE_TO_L3_EXECUTION',
    l2_gate['facts']['eligible_task_ids']==expected_l2_ids and l2_gate['facts']['model_requests_executed']==0 and l2_gate['facts']['scientific_outcomes_opened'] is False,
    l2_gate['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['source']['sha256']==l2_contract['support_contract']['source_sha256']==l2_gate['inputs']['source_sha256'],
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
