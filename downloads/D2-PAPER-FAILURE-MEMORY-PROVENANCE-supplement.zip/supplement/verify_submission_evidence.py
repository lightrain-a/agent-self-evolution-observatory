from pathlib import Path
import json,sys,hashlib
r=Path(__file__).resolve().parent/'evidence'
r4=json.load(open(r/'r4-terminal-swap.json'))
r5=json.load(open(r/'r5-exact-information-capacity.json'))
r6=json.load(open(r/'r6-early-action.json'))
sens=json.load(open(r/'stanford-r2-r4-threshold-sensitivity-r7.json'))
power=json.load(open(r/'prospective-power-planning-r7.json'))
l3=json.load(open(r/'l3-source-faithful-execution-contract-r7.json'))
style=json.load(open(r/'l1-operational-equivalence-stress-r7.json'))
repair=json.load(open(r/'stanford-r2-targeted-repair-r7.json'))
l2_manifest=json.load(open(r/'r5-eligibility-manifest-r8.json'))
l2_contract=json.load(open(r/'l2-reopen-contract-r8.json'))
l2_gate=json.load(open(r/'l2-analysis-gate-r8.json'))
l3_recheck=json.load(open(r/'l3-public-support-recheck-r8.json'))
l2_surface=json.load(open(r/'l2-metadata-surface-reconciliation-r8.json'))
l2b_preflight=json.load(open(r/'reasoningbank-status-l2-preflight-r9.json'))
l2b_power=json.load(open(r/'l2b-power-sensitivity-r9.json'))
l2b_contract=json.load(open(r/'l2b-adapter-contract-r9.json'))
l2b_census=json.load(open(r/'l2-reopen-substrate-census-r9.json'))
runtime_r10=json.load(open(r/'reasoningbank-runtime-compatibility-r10.json'))
runtime_addendum_r10=json.load(open(r/'l2b-runtime-addendum-r10.json'))
expected_l2_ids=['21','25','26','163','165']
checks=[
    r4['execution']['requests_complete']==48,
    r4['summary']['mean_success_minus_failure_terminal_rate']==0.166667,
    r4['summary']['support_gate_pass'] is False,
    r5['maximum_possible_unique_tasks_under_frozen_contract']==5,
    r5['model_requests_executed']==0,
    r6['information_equivalence']['eligible_pairs']==23,
    r6['summary']['requests_complete']==276,
    r6['summary']['mean_success_minus_failure_reference_match']==-0.094203,
    r6['summary']['support_gate_pass'] is False,
    r6['summary']['counterevidence_gate_pass'] is False,
    all(sens['threshold_results'][t]['eligible_pairs']==4 for t in ('0.75','0.85','0.90')),
    power['target_absolute_effect']==0.15 and power['target_power']==0.8,
    [x['one_sided_independent_tasks'] for x in power['planning_scenarios']]==[11,25,44],
    l3['current_status']=='NOT_EXECUTED_SUPPORT_AND_EXPERIMENT_DEBT',
    style['r4_stronger_semantic_audit']['reviewer_a_fully_equivalent']==0,
    style['r4_stronger_semantic_audit']['reviewer_b_fully_equivalent']==1,
    style['deterministic_writer_register_audit']['r6_failure_more_failure_caution']=='23/24',
    style['scientific_interpretation']['C4_causal_sign']=='UNRESOLVED',
    repair['policy']['new_model_calls'] is False and repair['frozen_scientific_boundary']['C4_causal_sign']=='UNRESOLVED',
    l2_manifest['summary']['target_unique_tasks']==10 and l2_manifest['summary']['eligible_unique_tasks']==5,
    l2_manifest['summary']['eligible_task_ids']==expected_l2_ids,
    l2_manifest['summary']['support_gate_pass'] is False and l2_manifest['summary']['model_requests_executed']==0,
    l2_manifest['summary']['scientific_outcomes_opened'] is False,
    l2_manifest['adjudication']['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['adjudication']['historical_5_of_10_value_reproduced'] is True,
    l2_contract['support_contract']['current_support_gate_pass'] is False,
    l2_contract['current_execution_gate']['model_calls_permitted'] is False and l2_contract['current_execution_gate']['scientific_outcome_execution_permitted'] is False,
    l2_contract['current_execution_gate']['current_model_call_budget']==0 and l2_contract['current_execution_gate']['l3_transition_permitted'] is False,
    l2_contract['scientific_authority'] is False and l2_contract['experiment_authority'] is False,
    l2_gate['status']=='STOP_SUPPORT_CAPACITY_NO_EXECUTION',
    l2_gate['decision']=='KEEP_L2_UNEXECUTED_AND_DO_NOT_ADVANCE_TO_L3_EXECUTION',
    l2_gate['facts']['eligible_task_ids']==expected_l2_ids and l2_gate['facts']['model_requests_executed']==0 and l2_gate['facts']['scientific_outcomes_opened'] is False,
    l2_gate['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    l2_manifest['source']['sha256']==l2_contract['support_contract']['source_sha256']==l2_gate['inputs']['source_sha256'],
    l3_recheck['status']=='NO_NEW_FIRST_PARTY_L3_ARTIFACT_DISCOVERED',
    l3_recheck['adjudication']['l3_support_unblocked'] is False,
    l3_recheck['adjudication']['l3_execution_authorized'] is False,
    l3_recheck['adjudication']['webarena_bridge_can_substitute_for_l3'] is False,
    l3_recheck['adjudication']['generic_reasoningbank_repo_can_substitute_for_financial_per_query_bundle'] is False,
    l3_recheck['adjudication']['scientific_verdict']=='NO_VERDICT_SUPPORT_FAILURE',
    not any(l3_recheck['authority'].values()),
    l2_surface['status']=='HISTORICAL_EXPLICIT_CUE_SURFACE_RECONCILED_NO_R5_RESCUE',
    l2_surface['historical_explicit_cue_bridge']['contract']['sha256']=='d6da08c7e57f13fe9b07951b2326b9fd400202b39e9ab039d18ee2d008c15c01',
    l2_surface['historical_explicit_cue_bridge']['result']['sha256']=='2097d4de2806a6fb576e5613c89c1a6ad3212e2f3ffe30090939a4585ab20394',
    l2_surface['historical_explicit_cue_bridge']['independent_tasks']==6 and l2_surface['historical_explicit_cue_bridge']['complete_calls']==144,
    l2_surface['historical_explicit_cue_bridge']['result_summary']['mean_success_minus_failure_terminal_rate']==0.0 and l2_surface['historical_explicit_cue_bridge']['result_summary']['permutation_p_success_greater']==1.0 and l2_surface['historical_explicit_cue_bridge']['result_summary']['permutation_p_failure_greater']==1.0,
    l2_surface['historical_explicit_cue_bridge']['result_summary']['decision']=='INCONCLUSIVE_NO_NEGATIVE_AUTHORITY' and l2_surface['historical_explicit_cue_bridge']['result_summary']['support_gate_pass'] is False and l2_surface['historical_explicit_cue_bridge']['result_summary']['counterevidence_gate_pass'] is False,
    l2_surface['historical_explicit_cue_bridge']['surface']['actionable_guidance_byte_identical_across_success_failure'] is True and l2_surface['historical_explicit_cue_bridge']['surface']['metadata_is_executor_visible'] is True and l2_surface['historical_explicit_cue_bridge']['surface']['memory_object_is_naturally_generated_reasoningbank_item'] is False,
    l2_surface['non_pooling_adjudication']['bridge_plus_r5_task_count_may_be_summed'] is False and l2_surface['non_pooling_adjudication']['bridge_effect_may_be_pooled_with_r5'] is False and l2_surface['non_pooling_adjudication']['bridge_can_rescue_r5_support_gate'] is False,
    l2_surface['frozen_r5_exact_information_l2']['eligible_unique_tasks']==5 and l2_surface['frozen_r5_exact_information_l2']['target_unique_tasks_support_floor']==10 and l2_surface['frozen_r5_exact_information_l2']['model_requests_executed']==0,
    l2_surface['power_and_support_boundary']['support_floor_is_not_power_guarantee'] is True and list(l2_surface['power_and_support_boundary']['one_sided_independent_tasks_by_task_level_sd'].values())==[11,25,44],
    l2_surface['stanford_o5_reconciliation']['disposition']=='REQUIRES_SCIENTIFIC_REOPEN' and l2_surface['stanford_o5_reconciliation']['scientific_fact'].startswith('R5 exact-information L2 itself remains unexecuted'),
    not any(l2_surface['authority'].values()),
    l2b_preflight['status']=='NATIVE_STATUS_FIELD_AND_36_UNIT_COHORT_VERIFIED_EXECUTION_BLOCKED',
    l2b_preflight['first_party_reasoningbank_binding']['commit']=='ed80611788292ea739f1effd31f16c53823b8a0d',
    all(l2b_preflight['first_party_reasoningbank_binding']['contract_checks'].values()),
    l2b_preflight['native_metadata_fact']['field']=='status' and l2b_preflight['native_metadata_fact']['stored_separately_from_actionable_memory'] is True and l2b_preflight['native_metadata_fact']['visible_to_default_downstream_agent'] is False,
    l2b_preflight['cohort_summary']['template_independent_units']==36 and len(set(l2b_preflight['cohort_summary']['downstream_task_ids']))==36,
    l2b_preflight['cohort_summary']['source_native_status_counts']=={'fail':21,'success':15},
    l2b_preflight['cohort_contract']['downstream_selection_uses_outcome'] is False and l2b_preflight['cohort_contract']['source_selection_uses_outcome'] is False,
    l2b_preflight['runtime_materialization']['current_69_exact_runtime_found'] is False and l2b_preflight['runtime_materialization']['support_engineering_materialization_requires_scientific_authority'] is False,
    not any(l2b_preflight['authority'].values()),
    l2b_power['maximum_frozen_independent_tasks']==36 and l2b_power['primary_hypothesis'].startswith('two-sided metadata effect'),
    [x['approx_two_sided_power'] for x in l2b_power['planning_scenarios']]==[0.994458,0.850839,0.614118],
    [x['two_sided_target_0_80_met'] for x in l2b_power['planning_scenarios']]==[True,True,False],
    l2b_power['planning_decision']['use_full_36_unit_cohort_if_executed'] is True and l2b_power['planning_decision']['claim_80_percent_power_unconditionally'] is False,
    l2b_contract['intervention']['memory_items_bytes_identical_across_arms'] is True and l2b_contract['intervention']['single_character_treatment_difference'] is True,
    l2b_contract['cohort']['independent_units']==36 and l2b_contract['cohort']['outcome_adaptive_subset_forbidden'] is True and l2b_contract['cohort']['post_outcome_replacement_forbidden'] is True,
    l2b_contract['separate_from_historical_objects']['pooling_with_R5_or_bridge'] is False and l2b_contract['separate_from_historical_objects']['L3_financial_transport'] is False,
    l2b_contract['primary_analysis']['primary_test']=='two-sided task-level paired randomization/sign-flip test' and l2b_contract['primary_analysis']['directional_sign_claim_predeclared'] is False,
    l2b_contract['execution_gate']['support_capacity_pass'] is True and l2b_contract['execution_gate']['exact_runtime_materialized'] is False and l2b_contract['execution_gate']['execution_permitted'] is False,
    l2b_contract['scientific_authority'] is False and l2b_contract['experiment_authority'] is False and l2b_contract['model_calls'] is False,
    hashlib.sha256((r/'reasoningbank-status-l2-preflight-r9.json').read_bytes()).hexdigest()==l2b_power['preflight_sha256']==l2b_contract['source_bindings']['preflight_sha256'],
    hashlib.sha256((r/'l2b-power-sensitivity-r9.json').read_bytes()).hexdigest()==l2b_contract['source_bindings']['power_sensitivity_sha256'],
    l2b_census['status']=='FIRST_PARTY_NATIVE_SOURCE_OUTCOME_FIELD_FOUND_ADAPTER_REQUIRED_EXECUTION_BLOCKED',
    l2b_census['census_adjudication']['qualified_exact_l2_surfaces_as_is']==0 and l2b_census['census_adjudication']['first_party_native_metadata_fields_requiring_exposure_adapter']==1,
    l2b_census['census_adjudication']['fresh_template_independent_units_for_adapter_candidate']==36 and l2b_census['census_adjudication']['o5_disposition']=='REQUIRES_SCIENTIFIC_REOPEN',
    not any(l2b_census['authority'].values()),
    runtime_r10['status']=='DECLARED_PY313_RUNTIME_NOT_DIRECTLY_MATERIALIZABLE_PY312_WEBARENA_COMPATIBILITY_PATH_VERIFIED',
    runtime_r10['first_party_runtime']['commit']=='ed80611788292ea739f1effd31f16c53823b8a0d',
    runtime_r10['first_party_runtime']['resolved_dependency_facts']['requires_python']=='>=3.13' and runtime_r10['first_party_runtime']['resolved_dependency_facts']['uv_lock_requires_python']=='>=3.13',
    runtime_r10['first_party_runtime']['resolved_dependency_facts']['browsergym_core']=='0.14.1' and runtime_r10['first_party_runtime']['resolved_dependency_facts']['playwright']=='1.44.0' and runtime_r10['first_party_runtime']['resolved_dependency_facts']['greenlet']=='3.0.3',
    runtime_r10['first_party_runtime']['resolved_dependency_facts']['greenlet_cp313_wheels_in_lock']==0,
    all(runtime_r10['python313_materialization_attempt']['markers'].values()) and runtime_r10['python313_materialization_attempt']['exit_code']==1,
    runtime_r10['adjudication']['exact_declared_python313_runtime_materialized'] is False and runtime_r10['adjudication']['exact_declared_runtime_support_failure'] is True and runtime_r10['adjudication']['support_failure_is_scientific_failure'] is False,
    runtime_r10['python312_compatibility_runtime']['python']=='3.12.13',
    runtime_r10['python312_compatibility_runtime']['versions']=={'browsergym':'0.14.1','browsergym-core':'0.14.1','browsergym-experiments':'0.14.1','browsergym-webarena':'0.14.1','playwright':'1.44.0','greenlet':'3.0.3','libwebarena':'0.0.4'},
    runtime_r10['python312_compatibility_runtime']['core_experiments_playwright_imports'] is True and runtime_r10['python312_compatibility_runtime']['webarena_import_completed'] is True and runtime_r10['python312_compatibility_runtime']['webarena_registered_task_ids']==812,
    runtime_r10['python312_compatibility_runtime']['playwright_chromium_revision']=='1117' and runtime_r10['python312_compatibility_runtime']['matching_default_chromium_cache_found'] is False,
    runtime_r10['python312_compatibility_runtime']['webarena_all_required_site_envs_present'] is False and runtime_r10['python312_compatibility_runtime']['live_webarena_deployment_detected'] is False,
    all(v=='' for v in runtime_r10['python312_compatibility_runtime']['webarena_site_env_configured'].values()),
    runtime_r10['adjudication']['python312_browsergym0141_component_path_materialized'] is True and runtime_r10['adjudication']['python312_webarena_import_verified'] is True,
    runtime_r10['adjudication']['python312_path_is_source_faithful_as_declared'] is False and runtime_r10['adjudication']['python312_path_may_be_silently_promoted_to_exact_runtime'] is False and runtime_r10['adjudication']['l3_financial_transport_unblocked'] is False,
    runtime_r10['adjudication']['scientific_verdict']=='NO_VERDICT_RUNTIME_SUPPORT_FAILURE' and not any(runtime_r10['authority'].values()),
    runtime_addendum_r10['status']=='PY312_BG0141_COMPATIBILITY_RUNTIME_SELECTED_PREOUTCOME_LIVE_DEPLOYMENT_BLOCKED',
    runtime_addendum_r10['runtime_policy']['selected_l2b_runtime_label']=='PY312_BG0141_EXPLICIT_COMPATIBILITY_DEVIATION' and runtime_addendum_r10['runtime_policy']['python']=='3.12.13' and runtime_addendum_r10['runtime_policy']['browsergym_webarena']=='0.14.1',
    runtime_addendum_r10['bindings']['cohort_units']==36 and runtime_addendum_r10['runtime_policy']['cohort_unchanged'] is True and runtime_addendum_r10['runtime_policy']['intervention_renderer_unchanged'] is True and runtime_addendum_r10['runtime_policy']['primary_analysis_unchanged'] is True,
    runtime_addendum_r10['identification_scope']['o6_l3_unblocked'] is False and 'exact-as-declared ReasoningBank runtime replication' in runtime_addendum_r10['identification_scope']['forbidden_claims'] and 'source-faithful financial AgentDojo transport' in runtime_addendum_r10['identification_scope']['forbidden_claims'],
    runtime_addendum_r10['live_runtime_support']['webarena_import_verified'] is True and runtime_addendum_r10['live_runtime_support']['registered_webarena_task_ids']==812 and runtime_addendum_r10['live_runtime_support']['expected_chromium_revision']=='1117',
    runtime_addendum_r10['live_runtime_support']['matching_chromium_cache_found'] is False and runtime_addendum_r10['live_runtime_support']['all_required_site_envs_present'] is False and runtime_addendum_r10['live_runtime_support']['live_webarena_deployment_detected'] is False,
    runtime_addendum_r10['execution_gate']['compatibility_package_runtime_materialized'] is True and runtime_addendum_r10['execution_gate']['webarena_import_verified'] is True and runtime_addendum_r10['execution_gate']['execution_permitted'] is False,
    runtime_addendum_r10['execution_gate']['scientific_authority'] is False and runtime_addendum_r10['execution_gate']['experiment_model_call_authority'] is False and not any(runtime_addendum_r10['authority'].values()),
    hashlib.sha256((r/'l2b-adapter-contract-r9.json').read_bytes()).hexdigest()==runtime_addendum_r10['bindings']['parent_r9_adapter_contract_sha256'],
    hashlib.sha256((r/'reasoningbank-runtime-compatibility-r10.json').read_bytes()).hexdigest()==runtime_addendum_r10['bindings']['r10_runtime_audit_sha256'],
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)})
sys.exit(0 if all(checks) else 1)
