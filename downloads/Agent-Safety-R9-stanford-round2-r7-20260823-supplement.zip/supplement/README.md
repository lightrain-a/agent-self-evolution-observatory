# Agent Safety R9 supplement — r7 Stanford round-2 paper-only repair

This public supplement contains the frozen R23 control evidence, code, the r6 post-hoc measurement-robustness diagnostic, and the r7 existing-evidence robustness receipt used to answer Stanford Agentic Reviewer round-2 concerns. No new agent, evaluator, or GPU execution is part of r7.

The original preregistration remains a private scientific object because three location fields contain internal filesystem paths. Its exact private file SHA-256 and embedded preregistration SHA are preserved in `evidence/agent-safety-r9-controlled-longitudinal-preregistration-public-r6.json`. The public projection changes only those location strings and has its own projection SHA; scientific values, episode schedules, thresholds, model/evaluator revisions, and authority flags are unchanged.

The 6/12 versus 3/12 action-trace projection is an analyst diagnostic only. The preregistered primary endpoint remains 8/12 versus 4/12. The 24-item human packet remains unlabeled and is not included in this public supplement or used by any claim.

Round-2 additions are bound in `evidence/agent-safety-r9-round2-robustness-r7.json`: exact paired small-n sensitivity for the 4--0 primary discordance, decoding/randomness transparency, pre-control selection timing, aggregate event-type measurement taxonomy, and explicit remaining experiment debt. These additions do not upgrade the primary finite-design claim or substitute for a NullMemory arm, a second judge/human labels, a longer horizon, or a second backbone.

Verification:

```bash
python3 supplement/verify_public_supplement_r6.py
python3 supplement/verify_round2_r7.py
```
