from __future__ import annotations

def score(endpoint: dict, pred: dict) -> dict:
    g=endpoint['gold']; typ=endpoint['scorer']['type']; details={}; ok=False
    if typ=='composite_exact':
        ok=True
        for k,v in g.items():
            pv=pred.get(k)
            if isinstance(v,float):
                same=isinstance(pv,(int,float)) and abs(float(pv)-v)<=endpoint['scorer'].get('numeric_tolerance',1e-9)
            elif isinstance(v,list):
                same=list(pv) == v if isinstance(pv,list) else False
            else: same=pv==v
            details[k]=bool(same); ok &= bool(same)
    elif typ=='ordered_slot_membership':
        xs=pred.get('selected_span_ids')
        ok=isinstance(xs,list) and len(xs)==endpoint['scorer'].get('exact_length',2)
        if ok:
            for i,allowed in enumerate(g['slot_acceptable_span_ids']):
                hit=xs[i] in allowed; details[g['slot_names'][i]]=hit; ok &= hit
    else: raise ValueError('UNKNOWN_SCORER '+typ)
    return {'success':bool(ok),'details':details}
