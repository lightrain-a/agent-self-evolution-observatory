import re

def skill(package, context):
    text = " ".join(package.get("document_text", "").split())
    match = re.search(r"(News) (Release|Archive|Statement)(?: and Data)? ([A-Za-z]{2,20})", text, re.I)
    value = None
    if match:
        value = f"{match.group(1)}-{match.group(3)}"
    return {"value": value}
