def skill(package, context):
    markers = ("table", "figure", "release", "appendix", "contact", "notes ", "technical notes", "page")
    chosen = []
    for span in package.get("candidate_spans", []):
        text = span.get("text", "").lower()
        sid = span.get("span_id", "")
        if any(marker in text for marker in markers):
            chosen.append(sid)
    return {"span_ids": chosen}
