def skill(package, context):
    limit = context.get("schema_ceiling", "")
    chosen = []
    for item in package.get("evidence_metadata", []):
        marker = item.get("schema_version", "")
        ref = item.get("evidence_ref", "")
        if isinstance(marker, str) and marker <= limit:
            chosen.append(ref)
    return {"evidence_refs": chosen}
