def skill(package, context):
    limit = context.get("cutoff_date", "")
    chosen = []
    for item in package.get("evidence_metadata", []):
        marker = item.get("release_date", "")
        ref = item.get("evidence_ref", "")
        if isinstance(marker, str) and marker <= limit:
            chosen.append(ref)
    return {"evidence_refs": chosen}
