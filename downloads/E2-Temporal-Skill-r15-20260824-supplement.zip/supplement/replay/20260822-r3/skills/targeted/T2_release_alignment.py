import re

def skill(package, context):
    text = " ".join(package.get("document_text", "").split())
    match = re.search(r"([1-4])(?:st|nd|rd|th) Quarter(?: and Year)? (20\d{2})", text, re.I)
    value = None
    if match:
        value = f"{match.group(2)}-Q{match.group(1)}"
    return {"value": value}
