def skill(package, context):
    markers = ("contributors to", "reflected", "because", "collectively", "favored", "favors ", "associated with", "due to")
    chosen = []
    for span in package.get("candidate_spans", []):
        text = span.get("text", "").lower()
        sid = span.get("span_id", "")
        if any(marker in text for marker in markers):
            chosen.append(sid)
    return {"span_ids": chosen}
