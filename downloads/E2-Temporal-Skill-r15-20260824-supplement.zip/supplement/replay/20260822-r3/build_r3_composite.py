from __future__ import annotations
import json, hashlib, os, random
from pathlib import Path

R2=Path('/data/wyt/agent-self-evolution-observatory/paper-acceptance/source-native-replay/D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK/20260822-r2')
R3=Path('/data/wyt/agent-self-evolution-observatory/paper-acceptance/source-native-replay/D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK/20260822-r3')
R3.mkdir(parents=True,exist_ok=True)
manifest=json.load(open(R2/'source_manifest.json'))
r2eps=json.load(open(R2/'endpoints.json'))['endpoints']
rels={r['evidence_ref']:r for r in manifest['releases']}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def text(r): return ' '.join(s['text'] for s in r['all_spans'])
def excerpt(r,n=10): return r['all_spans'][:n]

# Pre-outcome manual gold refinement: each grounding task requires evidence for two semantic slots.
# BEA: one direct contributor span + one comparison/revision span.
# NOAA: one current-state evidence span + one near-term outlook/support span.
ground_slots={
'doc_cc293f199ada': {'driver':['doc_cc293f199ada:s005'],'comparison':['doc_cc293f199ada:s009']},
'doc_65c03428faa4': {'driver':['doc_65c03428faa4:s005'],'comparison':['doc_65c03428faa4:s011']},
'doc_950378981b9f': {'driver':['doc_950378981b9f:s007','doc_950378981b9f:s011'],'comparison':['doc_950378981b9f:s005']},
'doc_187e543fe980': {'driver':['doc_187e543fe980:s004'],'comparison':['doc_187e543fe980:s007']},
'doc_5c43ed3f16d2': {'driver':['doc_5c43ed3f16d2:s004'],'comparison':['doc_5c43ed3f16d2:s006','doc_5c43ed3f16d2:s008']},
'doc_128dc1bd848f': {'state':['doc_128dc1bd848f:s002','doc_128dc1bd848f:s006','doc_128dc1bd848f:s007','doc_128dc1bd848f:s008','doc_128dc1bd848f:s009','doc_128dc1bd848f:s010'], 'outlook':['doc_128dc1bd848f:s011','doc_128dc1bd848f:s012','doc_128dc1bd848f:s013','doc_128dc1bd848f:s014']},
'doc_70e1e3d18499': {'state':['doc_70e1e3d18499:s001','doc_70e1e3d18499:s003','doc_70e1e3d18499:s004','doc_70e1e3d18499:s005','doc_70e1e3d18499:s006','doc_70e1e3d18499:s007','doc_70e1e3d18499:s008','doc_70e1e3d18499:s009'], 'outlook':['doc_70e1e3d18499:s010','doc_70e1e3d18499:s011','doc_70e1e3d18499:s012','doc_70e1e3d18499:s013']},
'doc_1dfccd3a55dd': {'state':['doc_1dfccd3a55dd:s002','doc_1dfccd3a55dd:s004','doc_1dfccd3a55dd:s005','doc_1dfccd3a55dd:s006','doc_1dfccd3a55dd:s007','doc_1dfccd3a55dd:s008','doc_1dfccd3a55dd:s009'], 'outlook':['doc_1dfccd3a55dd:s010','doc_1dfccd3a55dd:s011','doc_1dfccd3a55dd:s012','doc_1dfccd3a55dd:s013']},
'doc_15ffceb07aa2': {'state':['doc_15ffceb07aa2:s002','doc_15ffceb07aa2:s003','doc_15ffceb07aa2:s004','doc_15ffceb07aa2:s005','doc_15ffceb07aa2:s006','doc_15ffceb07aa2:s007','doc_15ffceb07aa2:s008'], 'outlook':['doc_15ffceb07aa2:s009','doc_15ffceb07aa2:s010','doc_15ffceb07aa2:s011','doc_15ffceb07aa2:s012','doc_15ffceb07aa2:s013']},
'doc_71b83aedc0f9': {'state':['doc_71b83aedc0f9:s001','doc_71b83aedc0f9:s002','doc_71b83aedc0f9:s003','doc_71b83aedc0f9:s004','doc_71b83aedc0f9:s005','doc_71b83aedc0f9:s006','doc_71b83aedc0f9:s007'], 'outlook':['doc_71b83aedc0f9:s008','doc_71b83aedc0f9:s009','doc_71b83aedc0f9:s010','doc_71b83aedc0f9:s011']},
}

endpoints=[]
for e in r2eps:
    fam=e['failure_family']
    if fam=='temporal_cutoff':
        admiss=e['gold']['admissible_evidence_refs']; latest=admiss[-1]; rr=rels[latest]
        records=[]
        for ref in e['evidence_refs']:
            r=rels[ref]
            records.append({'evidence_ref':ref,'release_date':r['release_date'],'document_spans':excerpt(r,10)})
        endpoints.append({
          'endpoint_id':e['endpoint_id'].replace('cutoff::','composite-cutoff::'), 'failure_family':fam,
          'domain':e['domain'],'publisher':e['publisher'],'cutoff_date':e['cutoff_date'],
          'task':'At the stated cutoff, identify the latest admissible institutional release and recover its reporting period and headline value. A post-cutoff release may be present. Do not use outside knowledge.',
          'output_schema':{'latest_evidence_ref':'string','reporting_period':'string','headline_value':'number','evidence_refs_used':'array[string]'},
          'package':{'evidence_metadata':[{'evidence_ref':x['evidence_ref'],'release_date':x['release_date'],'schema_version':'1'} for x in records], 'release_records':records},
          'skill_context':{'cutoff_date':e['cutoff_date'],'schema_ceiling':'1'},
          'gold':{'latest_evidence_ref':latest,'reporting_period':rr['reporting_period'],'headline_value':rr['headline_value'],'evidence_refs_used':[latest]},
          'scorer':{'type':'composite_exact','numeric_tolerance':1e-9},
          'phase':'C3-R' if e['cutoff_date']<'2026-04-01' else 'C4-R'
        })
    elif fam=='release_alignment':
        ref=e['evidence_refs'][0]; r=rels[ref]
        endpoints.append({
          'endpoint_id':e['endpoint_id'].replace('align::','composite-align::'), 'failure_family':fam,
          'domain':e['domain'],'publisher':e['publisher'],'cutoff_date':e['cutoff_date'],
          'task':'Read the first-party release. Recover the reporting quarter, estimate stage, and headline real-GDP annualized percent change. Distinguish publication date from reporting period. Do not use outside knowledge.',
          'output_schema':{'reporting_period':'string','release_stage':'string','headline_value':'number'},
          'package':{'document_text':text(r),'evidence_ref':ref},
          'skill_context':{},
          'gold':{'reporting_period':r['reporting_period'],'release_stage':r['release_stage'],'headline_value':r['headline_value']},
          'scorer':{'type':'composite_exact','numeric_tolerance':1e-9},
          'phase':'C3-R' if e['cutoff_date']<'2026-04-01' else 'C4-R'
        })
    elif fam=='exogenous_grounding':
        ref=e['evidence_refs'][0]; r=rels[ref]; slots=ground_slots[ref]
        slot_names=list(slots)
        if r['publisher']=='BEA':
            task='Select exactly two sentence span IDs from the supplied first-party release: one that directly states a principal contributor/driver of the reported GDP change, and one that directly explains the comparison with the prior estimate or prior quarter. Return them in slot order.'
        else:
            task='Select exactly two sentence span IDs from the supplied first-party ENSO discussion: one supporting the current ENSO state and one supporting the near-term outlook. Return them in slot order.'
        endpoints.append({
          'endpoint_id':e['endpoint_id'].replace('ground::','composite-ground::'), 'failure_family':fam,
          'domain':e['domain'],'publisher':e['publisher'],'cutoff_date':e['cutoff_date'],
          'task':task,
          'output_schema':{'selected_span_ids':'array[string] length=2'},
          'package':{'candidate_spans':r['all_spans'],'evidence_ref':ref},
          'skill_context':{},
          'gold':{'slot_names':slot_names,'slot_acceptable_span_ids':[slots[k] for k in slot_names]},
          'scorer':{'type':'ordered_slot_membership','exact_length':2},
          'phase':'C3-R' if e['cutoff_date']<'2026-04-01' else 'C4-R'
        })

endpoints=sorted(endpoints,key=lambda x:(x['failure_family'],x['cutoff_date'],x['endpoint_id']))
assert len(endpoints)==23
# Static leakage checks.
for e in endpoints:
    assert 'gold' not in e['task'].lower()
    if e['failure_family']=='temporal_cutoff':
        future=[m for m in e['package']['evidence_metadata'] if m['release_date']>e['cutoff_date']]
        assert future
    if e['failure_family']=='exogenous_grounding':
        assert len(e['package']['candidate_spans']) >= 19

out={'schema_version':'3.0','paper_id':'D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK','artifact_type':'source-native-composite-endpoints','parent_r2_endpoints_sha256':sha(R2/'endpoints.json'),'relationship_to_timesage':'Independent source-native mechanistic validation; not TimeSage-EV replication evidence.','endpoints':endpoints}
(R3/'endpoints.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
summary={
 'status':'PASS_PRE_OUTCOME_STATIC_QA','endpoint_count':len(endpoints),
 'phase_counts':{p:sum(x['phase']==p for x in endpoints) for p in ['C3-R','C4-R']},
 'family_counts':{f:sum(x['failure_family']==f for x in endpoints) for f in ['temporal_cutoff','release_alignment','exogenous_grounding']},
 'domain_counts':{d:sum(x['domain']==d for x in endpoints) for d in sorted({x['domain'] for x in endpoints})},
 'grounding_min_candidate_spans':min(len(x['package']['candidate_spans']) for x in endpoints if x['failure_family']=='exogenous_grounding'),
 'grounding_max_candidate_spans':max(len(x['package']['candidate_spans']) for x in endpoints if x['failure_family']=='exogenous_grounding'),
 'scientific_authority':False,'experiment_authority':False,'gpu_authority':False,
}
(R3/'qa.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps(summary,indent=2))
print('endpoints_sha256',sha(R3/'endpoints.json'))
