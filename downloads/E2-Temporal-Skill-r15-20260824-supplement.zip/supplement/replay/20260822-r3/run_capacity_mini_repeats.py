from __future__ import annotations
import argparse, concurrent.futures, hashlib, importlib.util, json, os, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PROJECT=Path('/home/wyt/code/agent-self-evolution-observatory')
sys.path.insert(0,str(PROJECT)); sys.path.insert(0,str(ROOT))
from research_pipeline.ark_provider import ArkSettings, ArkResponsesClient
from harness import render_prompt, extract_json
from scorer import score
R2=ROOT

def load_skill(condition):
    if condition=='N0': return None
    family={'1':'temporal_cutoff','2':'release_alignment','3':'exogenous_grounding'}[condition[-1]]
    side='targeted' if condition.startswith('T') else 'generic'
    pref=condition+'_'+family+'.py'
    p=R2/'skills'/side/pref
    spec=importlib.util.spec_from_file_location('sk_'+condition,p); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod.skill

def helper(endpoint,condition):
    fn=load_skill(condition)
    if fn is None:return None
    return fn(endpoint['package'],endpoint.get('skill_context') or {})

def run_one(row,endpoints,client,requested_model):
    e=endpoints[row['endpoint_id']]; h=helper(e,row['condition_id']); prompt=render_prompt(e,h)
    started=time.time(); err=None; text=''; parsed=None; sc={'success':False,'details':{}}; meta={}
    try:
      r=client.respond(prompt,model=requested_model,max_output_tokens=768,temperature=0,thinking='disabled')
      text=r['text']; parsed=extract_json(text); sc=score(e,parsed)
      meta={'resolved_model':r['resolved_model'],'status':r['status'],'usage':r.get('usage') or {},'provider_response_id_sha256':hashlib.sha256(str(r.get('response_id') or '').encode()).hexdigest()}
    except Exception as ex: err=f'{type(ex).__name__}:{ex}'
    return {**row,'backend':'ark_responses','runtime_seconds':round(time.time()-started,3),'prompt_sha256':hashlib.sha256(prompt.encode()).hexdigest(),'helper_output':h,'raw_text':text,'raw_text_sha256':hashlib.sha256(text.encode()).hexdigest(),'parsed':parsed,'success':bool(sc['success']),'score_details':sc['details'],'error':err,**meta}

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--phase',choices=['C3-R','C4-R','ALL'],default='ALL'); ap.add_argument('--model-id',choices=['ARK-DOUBAO-SEED-2.0-MINI'],required=True); ap.add_argument('--repeat',type=int,choices=[1,2,3,4],required=True); ap.add_argument('--workers',type=int,default=4); args=ap.parse_args()
 eps={e['endpoint_id']:e for e in json.load(open(ROOT/'endpoints.json'))['endpoints']}; plan=json.load(open(ROOT/'capacity_stress_mini_repeats_plan.json'))
 rows=[r for r in plan['rows'] if r['model_id']==args.model_id and r['repeat_id']==args.repeat and (args.phase=='ALL' or r['phase']==args.phase)]; requested_model={'ARK-DOUBAO-SEED-2.0-MINI':'doubao-seed-2.0-mini'}[args.model_id]
 settings=ArkSettings.from_env();
 def task(r): return run_one(r,eps,ArkResponsesClient(settings),requested_model)
 with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex: results=list(ex.map(task,rows))
 tag={'ARK-DOUBAO-SEED-2.0-MINI':'mini'}[args.model_id]; out=ROOT/f"repeat_{args.repeat}_{tag}_{args.phase.lower().replace('-','_')}.json"
 payload={'schema_version':'1.0','model_id':args.model_id,'requested_model':requested_model,'repeat_id':args.repeat,'phase':args.phase,'rows':results,'summary':{'total':len(results),'runtime_valid':sum(not r['error'] for r in results),'successes':sum(r['success'] for r in results)}}
 out.write_text(json.dumps(payload,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
 print(json.dumps(payload['summary'],indent=2)); print('output',out); print('sha256',hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__': main()
