from __future__ import annotations
import argparse, concurrent.futures, hashlib, importlib.util, json, sys
from pathlib import Path
sys.path.insert(0,'/home/wyt/code/agent-self-evolution-observatory')
from research_pipeline.ark_provider import ArkResponsesClient, ArkSettings
ROOT=Path(__file__).resolve().parent

def lm(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);assert s and s.loader;s.loader.exec_module(m);return m
h=lm(ROOT/'harness.py','h');sc=lm(ROOT/'scorer.py','sc');T=lm(ROOT/'skills/targeted/T1_temporal_cutoff.py','T');G=lm(ROOT/'skills/generic/G1_temporal_cutoff.py','G')
eps={e['endpoint_id']:e for e in json.load(open(ROOT/'endpoints.json'))['endpoints']}
plan=json.load(open(ROOT/'execution_plan.json'))

def sh(s):return hashlib.sha256(s.encode()).hexdigest()
def run(row,settings):
 e=eps[row['endpoint_id']];cid=row['condition_id'];helper=None
 if cid=='T1':helper=T.skill(e['package'],e['skill_context'])
 elif cid=='G1':helper=G.skill(e['package'],e['skill_context'])
 prompt=h.render_prompt(e,helper);c=ArkResponsesClient(settings)
 rec={k:row[k] for k in ['model_id','requested_model','model_role','repeat_id','phase','endpoint_id','failure_family','domain','condition_id','condition_position','skill_source_sha256']};rec.update({'cutoff_date':e['cutoff_date'],'helper_output':helper,'prompt_sha256':sh(prompt),'runtime_valid':False,'family_success':False,'strict_success':False})
 try:
  r=c.respond(prompt,model=row['requested_model'],max_output_tokens=768,temperature=0,thinking='disabled');txt=r['text'];pred=h.extract_json(txt);fam=sc.family_score(e,pred);strict=sc.strict_score(e,pred)
  rec.update({'resolved_model':r['resolved_model'],'status':r['status'],'provider_response_id_sha256':sh(r.get('response_id') or ''),'usage':r.get('usage',{}),'raw_text':txt,'raw_text_sha256':sh(txt),'prediction':pred,'family_score':fam,'strict_score':strict,'runtime_valid':True,'family_success':bool(fam['success']),'strict_success':bool(strict['success'])})
 except Exception as ex: rec.update({'error_type':type(ex).__name__,'error':str(ex)[:1200]})
 return rec

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--model-id',required=True,choices=['ARK-DEEPSEEK-V4-PRO','ARK-DOUBAO-SEED-2.0-MINI']);ap.add_argument('--workers',type=int,default=6);args=ap.parse_args()
 rows=[r for r in plan['rows'] if r['model_id']==args.model_id];settings0=ArkSettings.from_env(required=True);settings=ArkSettings(api_key=settings0.api_key,base_url=settings0.base_url,default_model=settings0.default_model,timeout_seconds=180,max_retries=1)
 with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex: results=list(ex.map(lambda r:run(r,settings),rows))
 results.sort(key=lambda x:(x['repeat_id'],x['phase'],x['endpoint_id'],x['condition_position']))
 tag='deepseek' if args.model_id=='ARK-DEEPSEEK-V4-PRO' else 'mini';payload={'schema_version':'1.0','paper_id':'D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK','track':'r4-postreview-eia-cutoff','model_id':args.model_id,'rows':results,'counts':{'total':len(results),'runtime_valid':sum(x['runtime_valid'] for x in results),'family_successes':sum(x['family_success'] for x in results),'strict_successes':sum(x['strict_success'] for x in results)}};out=ROOT/f'r4_{tag}_results.json';out.write_text(json.dumps(payload,indent=2,sort_keys=True)+'\n');print(json.dumps(payload['counts'],indent=2));print(out);print(hashlib.sha256(out.read_bytes()).hexdigest())
if __name__=='__main__':main()
