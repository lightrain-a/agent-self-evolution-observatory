from __future__ import annotations
import json,re
SYSTEM="""You are a temporal analysis agent. Work only from the supplied first-party evidence package. Do not use outside knowledge. Respect the stated cutoff. Return one JSON object matching the requested output schema, with no markdown or extra prose."""
def render_prompt(endpoint,helper_output):
 payload={'task':endpoint['task'],'cutoff_date':endpoint['cutoff_date'],'output_schema':endpoint['output_schema'],'evidence_package':endpoint['package'],'reusable_helper_output':helper_output if helper_output is not None else None}
 rule=("A reusable helper was executed before this answer. Its output is procedural assistance only; verify it against the evidence before answering." if helper_output is not None else "No reusable helper output is available for this run.")
 return SYSTEM+'\n'+rule+'\nINPUT_JSON:\n'+json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def extract_json(text):
 s=text.strip(); s=re.sub(r'^```(?:json)?\s*','',s,flags=re.I) if s.startswith('```') else s; s=re.sub(r'\s*```$','',s); a,b=s.find('{'),s.rfind('}');
 if a<0 or b<a: raise ValueError('NO_JSON_OBJECT')
 x=json.loads(s[a:b+1]);
 if not isinstance(x,dict): raise ValueError('JSON_NOT_OBJECT')
 return x
