from __future__ import annotations
from datetime import datetime
def _date(x):
 if not isinstance(x,str): return None
 s=x.strip()
 for f in ('%Y-%m-%d','%B %d, %Y','%b %d, %Y'):
  try:return datetime.strptime(s,f).date().isoformat()
  except ValueError:pass
 return None
def family_score(endpoint,pred):
 valid=set(endpoint['gold']['admissible_evidence_refs']); refs=pred.get('evidence_refs_used'); latest=pred.get('latest_evidence_ref')
 ok=isinstance(refs,list) and bool(refs) and latest==endpoint['gold']['latest_evidence_ref'] and latest in refs and all(x in valid for x in refs)
 return {'success':bool(ok),'valid_refs':sorted(valid),'refs':refs,'latest':latest}
def strict_score(endpoint,pred):
 fam=family_score(endpoint,pred); refs=pred.get('evidence_refs_used'); exact=isinstance(refs,list) and set(refs)==set(endpoint['gold']['admissible_evidence_refs']) and len(refs)==len(endpoint['gold']['admissible_evidence_refs']); period=_date(pred.get('reporting_period'))==endpoint['gold']['reporting_period']; return {'success':bool(fam['success'] and exact and period),'family_success':fam['success'],'exact_set':exact,'period_match':period}
