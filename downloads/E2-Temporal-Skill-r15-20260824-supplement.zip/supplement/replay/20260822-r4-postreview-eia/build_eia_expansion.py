from __future__ import annotations
import hashlib, html, json, random, re, shutil
from datetime import datetime
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parent
RAW=ROOT/'raw'; RAW.mkdir(exist_ok=True)
R3=Path('/data/wyt/agent-self-evolution-observatory/paper-acceptance/source-native-replay/D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK/20260822-r3')
DATES=['2026_02_11','2026_02_19','2026_02_25','2026_03_04','2026_03_11','2026_03_18','2026_03_25','2026_04_01','2026_04_08','2026_04_15','2026_04_22','2026_04_29','2026_05_06','2026_05_13','2026_05_20','2026_05_28']
EXPECTED_T1='df1950ef3930544bde8ed9211b6af87299ef8cc2fdbd5d8918ed63538d56d522'
EXPECTED_G1='86f8b1e6f052b52c5c21c5c5b0b744aa7cfc0a2fdbb44d1154df9f629f985c6a'

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def sha_file(p:Path)->str:return sha_bytes(p.read_bytes())
def iso(s:str)->str:return datetime.strptime(s.strip(),'%B %d, %Y').date().isoformat()
def visible(raw:str)->str:
    s=re.sub(r'<!--.*?-->',' ',raw,flags=re.S)
    s=re.sub(r'<script.*?</script>|<style.*?</style>',' ',s,flags=re.I|re.S)
    s=re.sub(r'<[^>]+>',' ',s)
    return html.unescape(' '.join(s.split()))

sources=[]
for token in DATES:
    u=f'https://www.eia.gov/petroleum/supply/weekly/archive/2026/{token}/wpsr_{token}.php'
    r=requests.get(u,timeout=30); r.raise_for_status(); raw=r.content
    rp=RAW/f'wpsr_{token}.html'; rp.write_bytes(raw)
    text=visible(raw.decode('utf-8','replace'))
    m=re.search(r'Data for week ending\s+(.+?)\s+\|\s+Release Date:\s+(.+?)\s+\|',text)
    if not m: raise RuntimeError(f'header parse failed {u}')
    data_ending,release=m.groups(); release_iso=iso(release); data_iso=iso(data_ending)
    ref='doc_'+sha_bytes(raw)[:12]
    sources.append({'internal_id':f'eia_wpsr_{token}','evidence_ref':ref,'publisher':'EIA','domain':'energy','url':u,'release_date':release_iso,'reporting_period':data_iso,'raw_sha256':sha_bytes(raw),'raw_bytes':len(raw),'raw_source_ref':str(rp),'visible_header':f'Data for week ending {data_ending} | Release Date: {release}','document_spans':[{'span_id':f'{ref}:s000','text':'Weekly Petroleum Status Report'},{'span_id':f'{ref}:s001','text':f'Data for week ending {data_ending}'},{'span_id':f'{ref}:s002','text':f'Release Date: {release}'}]})

# Freeze exactly 12 targets. Each package has up to 4 historical/current records and exactly one next-release distractor.
endpoints=[]
for i in range(3,15):
    target=sources[i]; past=sources[max(0,i-3):i+1]; future=sources[i+1]; records=past+[future]
    valid=[x['evidence_ref'] for x in past]
    phase='C3-R4' if target['release_date']<'2026-04-01' else 'C4-R4'
    endpoints.append({
      'endpoint_id':f"eia-cutoff::{target['evidence_ref']}",
      'phase':phase,'failure_family':'temporal_cutoff','publisher':'EIA','domain':'energy','cutoff_date':target['release_date'],
      'task':'At the stated cutoff, identify the latest admissible EIA Weekly Petroleum Status Report and recover the data-ending week represented by that release. One post-cutoff distractor is present. Use only the supplied first-party package.',
      'output_schema':{'evidence_refs_used':'array[string]','latest_evidence_ref':'string','reporting_period':'string'},
      'package':{'evidence_metadata':[{'evidence_ref':x['evidence_ref'],'release_date':x['release_date'],'schema_version':'1'} for x in records], 'release_records':[{'evidence_ref':x['evidence_ref'],'release_date':x['release_date'],'document_spans':x['document_spans']} for x in records]},
      'skill_context':{'cutoff_date':target['release_date'],'schema_ceiling':'1'},
      'gold':{'admissible_evidence_refs':valid,'latest_evidence_ref':target['evidence_ref'],'reporting_period':target['reporting_period']},
      'future_distractor':future['evidence_ref'],
      'primary_family_scorer':'latest ref must equal the cutoff-time target; every cited ref must be nonempty and cutoff-valid; no post-cutoff ref may be cited. Reporting-period formatting is not part of primary family success.',
      'strict_scorer':'exact admissible set + exact latest ref + semantically normalized data-ending date',
      'post_review_validation':True,
    })

# Copy unchanged skills and assert identity.
(ROOT/'skills/targeted').mkdir(parents=True,exist_ok=True);(ROOT/'skills/generic').mkdir(parents=True,exist_ok=True)
shutil.copy2(R3/'skills/targeted/T1_temporal_cutoff.py',ROOT/'skills/targeted/T1_temporal_cutoff.py')
shutil.copy2(R3/'skills/generic/G1_temporal_cutoff.py',ROOT/'skills/generic/G1_temporal_cutoff.py')
if sha_file(ROOT/'skills/targeted/T1_temporal_cutoff.py')!=EXPECTED_T1: raise RuntimeError('T1 drift')
if sha_file(ROOT/'skills/generic/G1_temporal_cutoff.py')!=EXPECTED_G1: raise RuntimeError('G1 drift')

manifest={'schema_version':'1.0','artifact_type':'post-review-source-native-energy-expansion','paper_id':'D2-PAPER-TEMPORAL-SKILL-CAUSAL-BOTTLENECK','status':'FROZEN_BEFORE_R4_MODEL_OUTCOMES','review_trigger':'Mock-PC sample-size/domain-breadth concern','scope':'T1 temporal-cutoff only; no T2/T3 changes','sources':sources,'source_count':len(sources),'endpoint_count':len(endpoints),'phase_counts':{'C3-R4':sum(e['phase']=='C3-R4' for e in endpoints),'C4-R4':sum(e['phase']=='C4-R4' for e in endpoints)},'domain':'energy','publisher':'EIA','frozen_skill_hashes':{'T1':EXPECTED_T1,'G1':EXPECTED_G1},'scientific_authority':False,'experiment_authority':False,'gpu_authority':False}
(ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
(ROOT/'endpoints.json').write_text(json.dumps({'schema_version':'1.0','endpoints':endpoints},indent=2,sort_keys=True)+'\n')

# Frozen prompt harness.
harness='''from __future__ import annotations\nimport json,re\nSYSTEM="""You are a temporal analysis agent. Work only from the supplied first-party evidence package. Do not use outside knowledge. Respect the stated cutoff. Return one JSON object matching the requested output schema, with no markdown or extra prose."""\ndef render_prompt(endpoint,helper_output):\n payload={'task':endpoint['task'],'cutoff_date':endpoint['cutoff_date'],'output_schema':endpoint['output_schema'],'evidence_package':endpoint['package'],'reusable_helper_output':helper_output if helper_output is not None else None}\n rule=("A reusable helper was executed before this answer. Its output is procedural assistance only; verify it against the evidence before answering." if helper_output is not None else "No reusable helper output is available for this run.")\n return SYSTEM+'\\n'+rule+'\\nINPUT_JSON:\\n'+json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))\ndef extract_json(text):\n s=text.strip(); s=re.sub(r'^```(?:json)?\\s*','',s,flags=re.I) if s.startswith('```') else s; s=re.sub(r'\\s*```$','',s); a,b=s.find('{'),s.rfind('}');\n if a<0 or b<a: raise ValueError('NO_JSON_OBJECT')\n x=json.loads(s[a:b+1]);\n if not isinstance(x,dict): raise ValueError('JSON_NOT_OBJECT')\n return x\n'''
(ROOT/'harness.py').write_text(harness)
scorer='''from __future__ import annotations\nfrom datetime import datetime\ndef _date(x):\n if not isinstance(x,str): return None\n s=x.strip()\n for f in ('%Y-%m-%d','%B %d, %Y','%b %d, %Y'):\n  try:return datetime.strptime(s,f).date().isoformat()\n  except ValueError:pass\n return None\ndef family_score(endpoint,pred):\n valid=set(endpoint['gold']['admissible_evidence_refs']); refs=pred.get('evidence_refs_used'); latest=pred.get('latest_evidence_ref')\n ok=isinstance(refs,list) and bool(refs) and latest==endpoint['gold']['latest_evidence_ref'] and latest in refs and all(x in valid for x in refs)\n return {'success':bool(ok),'valid_refs':sorted(valid),'refs':refs,'latest':latest}\ndef strict_score(endpoint,pred):\n fam=family_score(endpoint,pred); refs=pred.get('evidence_refs_used'); exact=isinstance(refs,list) and set(refs)==set(endpoint['gold']['admissible_evidence_refs']) and len(refs)==len(endpoint['gold']['admissible_evidence_refs']); period=_date(pred.get('reporting_period'))==endpoint['gold']['reporting_period']; return {'success':bool(fam['success'] and exact and period),'family_success':fam['success'],'exact_set':exact,'period_match':period}\n'''
(ROOT/'scorer.py').write_text(scorer)

models=[{'model_id':'ARK-DEEPSEEK-V4-PRO','requested_model':'deepseek-v4-pro','role':'primary-model-post-review-validation'},{'model_id':'ARK-DOUBAO-SEED-2.0-MINI','requested_model':'doubao-seed-2.0-mini','role':'capacity-regime-post-review-validation'}]
rows=[]; seed_tag='D2-TEMPORAL-R4-EIA-POSTREVIEW-20260822-v1'
for rep in range(5):
 for model in models:
  for e in endpoints:
   trip=[('N0',None),('G1',EXPECTED_G1),('T1',EXPECTED_T1)]; order=list(range(3)); seed=int(hashlib.sha256(f"{seed_tag}|{rep}|{model['model_id']}|{e['endpoint_id']}".encode()).hexdigest()[:16],16);random.Random(seed).shuffle(order)
   for pos,j in enumerate(order):
    cid,skillsha=trip[j];rows.append({'model_id':model['model_id'],'requested_model':model['requested_model'],'model_role':model['role'],'repeat_id':rep,'phase':e['phase'],'endpoint_id':e['endpoint_id'],'failure_family':'temporal_cutoff','domain':'energy','condition_id':cid,'condition_position':pos,'skill_source_sha256':skillsha})
plan={'schema_version':'1.0','artifact_type':'post-review-eia-r4-execution-plan','paper_id':manifest['paper_id'],'status':'FROZEN_BEFORE_R4_MODEL_OUTCOMES','models':models,'repeat_count':5,'conditions':['N0','G1','T1'],'rows':rows,'counts':{'total':len(rows),'C3-R4':sum(r['phase']=='C3-R4' for r in rows),'C4-R4':sum(r['phase']=='C4-R4' for r in rows)},'seed_tag':seed_tag,'no_outcome_dependent_ordering':True,'scientific_authority':False,'experiment_authority':False,'gpu_authority':False}
(ROOT/'execution_plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n')
qa={'status':'PASS','source_count':len(sources),'endpoint_count':len(endpoints),'future_distractor_count':sum(bool(e['future_distractor']) for e in endpoints),'opaque_ids':all(re.fullmatch(r'doc_[0-9a-f]{12}',s['evidence_ref']) for s in sources),'T1_identity':sha_file(ROOT/'skills/targeted/T1_temporal_cutoff.py')==EXPECTED_T1,'G1_identity':sha_file(ROOT/'skills/generic/G1_temporal_cutoff.py')==EXPECTED_G1,'endpoints_sha256':sha_file(ROOT/'endpoints.json'),'source_manifest_sha256':sha_file(ROOT/'source_manifest.json'),'harness_sha256':sha_file(ROOT/'harness.py'),'scorer_sha256':sha_file(ROOT/'scorer.py'),'execution_plan_sha256':sha_file(ROOT/'execution_plan.json')}
(ROOT/'qa.json').write_text(json.dumps(qa,indent=2,sort_keys=True)+'\n')
print(json.dumps(qa,indent=2));print('rows',len(rows))
