# Reward Errors Change Memory Before They Change Policy — stage-resolved B11 supplement

This anonymous supplement extends the C1 evidence with an outcome-blind structured-memory control and a stage-resolved story audit.

**Outcome-blind writer.** The same 20 source tasks and action-summary bytes are rewritten with the same DeepSeek-V4-Flash writer family and the same Title/Description/Content schema, but without success/failure, reward, score, or outcome semantics. All 20 calls complete, including all 11 sources selected by the native retriever.

**Native neutral-memory terminal arm.** On the same 36 native tasks, 144/144 calls complete. Mean reward-conditioned-versus-neutral effect is 0.045139 with permutation p=0.0048, below the unchanged 0.15 practical floor. Thirty-two tasks have zero effect and 30/36 have identical success, failure, neutral, raw-trajectory, and no-memory point estimates.

**Concentration boundary.** The detected small effect is highly localized. Task 229 contributes 61.5% of absolute effect mass and 87.7% of squared effect mass; removing it lowers the mean to 0.017857. Only 2/11 native-selected sources contain any nonzero future task. This diagnostic is descriptive and does not alter the preregistered gate.

**CSV provenance.** The supplement includes deterministic projections with 20 writer rows, 144 terminal-rollout rows, and 36 cell rows. The scientific source of truth remains the immutable response-first/per-stage JSON evidence; the CSVs make interruption recovery and downstream audit easier.

The current story is stage-resolved: write -> exposure -> branch-specific policy uptake -> outcome. A 144-call neutral first-action arm is intentionally deferred because it is unnecessary for the current narrow branch-specific claim; it is reopened only if the paper expands to generic structured-memory presence or formal mediation.

B11 adds 164 scientifically usable provider calls. The full-paper observable provider-POST lower bound is at least 2,079. No training or local GPU fine-tuning is used. Stable canonical PaperRegistry is not overwritten and no daytime external review is triggered.

Run `python verify_current_supplement.py` to validate the public projection.
