from pathlib import Path
import json,sys,csv
R=Path(__file__).resolve().parent;E=R/'evidence'
def L(n):return json.load(open(E/n))
q=L('manuscript-qa.json');b=L('b11-scientific-evidence.json');c=L('b11-concentration-evidence.json');s=L('story-v4-argument-search-20260824.json');r=L('stage-resolved-b11-revision-receipt.json');wr=L('b11-writer-result-public.json')['payload'];tr=L('b11-terminal-result-public.json')['payload'];p=json.load(open(R/'CURRENT-PROJECTION.json'))
def rows(n):
 with open(R/'csv'/n,newline='',encoding='utf-8') as f:return sum(1 for _ in csv.DictReader(f))
w=b['writer_stage'];t=b['terminal_stage'];a=b['execution_accounting'];cc=c['summary']
checks=[
 q['status']=='PASS',q['revision']=='ICLR-STAGE-RESOLVED-B11-20260824',sum(q['checks'].values())==len(q['checks'])==43,q['abstract_words_approx']==191,q['main_text_pages']==9,q['references_begin_page']==10,q['pdf_pages_total']==19,q['new_provider_calls_exact']==164,q['new_scientifically_usable_writer_calls']==20,q['new_terminal_rollouts']==144,q['updated_full_paper_observable_provider_posts_lower_bound']==2079,
 s['status']=='STORY_SEARCH_COMPLETE_WINNER_FROZEN',s['winner']['id']=='S1-WRITE-TO-UPTAKE-BOTTLENECK',s['winner']['score']==98,s['additional_experiment_adjudication']['verdict']=='DEFER_NOT_NEEDED_FOR_CURRENT_CLAIM',s['additional_experiment_adjudication']['provider_calls_avoided']==144,
 b['status']=='B11_OUTCOME_BLIND_STRUCTURED_CONTROL_COMPLETE',w['complete_calls']==20,w['provider_failures']==0,w['required_native_sources_complete']==11,abs(w['mean_neutral_to_success_token_jaccard_distance']-.61179)<1e-12,abs(w['mean_neutral_to_failure_token_jaccard_distance']-.690062)<1e-12,w['neutral_title_set_equals_success_sources']==0,w['neutral_title_set_equals_failure_sources']==0,
 t['complete_calls']==144,t['provider_failures']==0,abs(t['mean_absolute_reward_conditioned_vs_neutral_effect']-.045139)<1e-12,abs(t['permutation_p']-.0048)<1e-12,abs(t['practical_effect_floor']-.15)<1e-12,t['primary_gate_pass'] is False,t['zero_effect_tasks']==32,t['all_five_arms_equal_tasks']==30,
 c['status']=='B11_ZERO_CALL_CONCENTRATION_COMPLETE',c['provider_calls']==0,cc['top1_effect_task']==229,abs(cc['top1_share_of_absolute_effect_mass']-.615385)<1e-12,abs(cc['top1_share_of_squared_effect_mass']-.876712)<1e-12,abs(cc['top2_share_of_squared_effect_mass']-.931507)<1e-12,abs(cc['minimum_leave_one_task_out_mean_effect']-.017857)<1e-12,cc['sources_with_nonzero_effect']==2,cc['native_selected_source_count']==11,
 wr['status']=='B11_WRITER_COMPLETE',wr['summary']['provider_calls_complete']==20,wr['summary']['provider_failures']==0,tr['status']=='B11_TERMINAL_EXECUTION_COMPLETE',tr['summary']['provider_calls_complete']==144,tr['summary']['provider_failures']==0,abs(tr['summary']['observed_mean_absolute_reward_conditioned_vs_neutral_effect']-.045139)<1e-12,tr['summary']['primary_gate_pass'] is False,
 a['b11_total_provider_posts']==164,a['b11_scientifically_usable_provider_completions']==164,a['full_paper_observable_provider_posts_lower_bound_after_b11']==2079,
 rows('b11-writer-calls.csv')==20,rows('b11-terminal-rollouts.csv')==144,rows('b11-cell-results.csv')==36,
 r['status']=='STAGE_RESOLVED_B11_INTEGRATED_QA_PASS',r['title']=='Reward Errors Change Memory Before They Change Policy',r['external_review_calls_current_revision']==0,r['canonical_stable_registry_overwritten'] is False,
 p['revision']=='iclr-stage-resolved-b11-20260824',p['story_winner']=='S1-WRITE-TO-UPTAKE-BOTTLENECK',p['claim_expansion'] is False,p['reward_conditioned_vs_neutral_gate_pass'] is False,abs(p['reward_conditioned_vs_neutral_effect']-.045139)<1e-12,abs(p['top_effect_absolute_mass_share']-.615385)<1e-12,abs(p['leave_top_task_out_mean_effect']-.017857)<1e-12,p['full_paper_observable_provider_posts_lower_bound']==2079,p['canonical_stable_registry_overwritten'] is False,
]
print({'checks':len(checks),'passed':sum(checks),'pass':all(checks)});sys.exit(0 if all(checks) else 1)
