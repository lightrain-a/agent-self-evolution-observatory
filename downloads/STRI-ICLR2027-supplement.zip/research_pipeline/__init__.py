"""Minimal STRI reproduction package."""
