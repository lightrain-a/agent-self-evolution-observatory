# STRI ICLR 2027 supplementary reproduction package

This anonymous package reproduces the load-bearing **static** results in the STRI submission. It deliberately does **not** turn the qualification-failed Qwen3-8B pilot into scientific evidence.

## Contents

- `data/skillsp-toolcall-membership.jsonl`: 530 frozen Skill-SP API-Bank membership rows evaluated by released validators.
- `data/skillsp-logical-support-matrix.jsonl`: 128 author-valid logical compiler units cross-checked against 8 released compiler specs.
- `research_pipeline/asset_first_stri_certificate.py`: exact `R*(A)` LP and STRI-Cert logic.
- `research_pipeline/asset_first_stri_structural_witness.py`: closed-form global-singleton factor-2 witness.
- `research_pipeline/asset_first_stri_paper_analysis_suite.py`: exact-clone/split quotient ablations, matched reduction summary, failure taxonomy, leave-one-out sensitivity, and fixed-seed tool-resampling robustness.
- `artifacts/`: frozen result receipts used by the paper, including the matched baseline ladder, clone/split representation ablations, failure/sensitivity analysis, the logical negative boundary, SkillRL identity witness, whole-package-pruning reduction, and the Qwen3 qualification failure.
- `paper_drafts/`: scripts for the four paper figures; Fig. 2/3 consume the frozen machine-readable table data.
- `protocols/`: sanitized first-party regeneration contracts. They point to relative `external/` clones rather than any author-local path.

## Environment

Python 3.10+ with NumPy, SciPy, and Matplotlib. The frozen development environment used NumPy 2.2.6, SciPy 1.15.3, and Matplotlib 3.10.8.

```bash
python -m pip install -r requirements.txt
```

## One-command static reproduction

```bash
python reproduce.py
```

Expected result: `status=PASS`, with Level-1 full/calibration/tool-disjoint heldout `R*=2`, Level-3 `R*=1`, logical compiler support `127/128` multi-membership with `R*=1`, minimum exact-coverage pruning `10 -> 7` active packages while `71` overlap rows remain, SkillRL `12/12` clone admission with `11/12` unique semantic retrieval-set changes and `5/12` reductions, and Qwen P0-A retained as `INCONCLUSIVE_PROPOSER_QUALIFICATION_FAILED` (`14/5/8 < 16` valid/source). The Paper Quality v2.1 analysis additionally verifies exact row-support recovery for every active-package clone/split quotient, 49/49 leave-one-tool and 399/399 leave-one-row retention of both Level-1 closed-form witnesses, and 97.2% retention of both witnesses over 500 fixed-seed tool bootstrap resamples (100% retain at least one).

## Unit tests

```bash
python -m unittest discover -s research_pipeline -t . -p 'test_asset_first_stri_*.py'
```

These exercise the exact LP, the closed-form witness, the high-overlap-but-equalizable boundary, and fail-closed logical classification.

## Figure regeneration

```bash
python paper_drafts/stri-20260816-plot-overview.py
python paper_drafts/stri-20260816-plot-witnesses.py
python paper_drafts/stri-20260816-plot-boundary.py
python paper_drafts/stri-20260816-plot-ablation-robustness.py
```

Outputs are written to `paper_drafts/figures/`.

## Regenerating first-party matrices from released repositories

The supplied matrices are sufficient to recompute the paper's certificate results. To regenerate the upstream released-system probes, clone the corresponding author repositories into `external/` at the frozen commits and run the included contracts/scripts.

### Skill Self-Play logical compiler support

```bash
git clone https://github.com/Qwen-Applications/skill-self-play.git external/skill-self-play
git -C external/skill-self-play checkout bb693c89fee66e1f824d6a777759a49b7a295a83
python -m research_pipeline.asset_first_stri_logical_support \
  --contract protocols/skillsp-logical-support-contract.json \
  --output-dir outputs/logical-regeneration
```

The contract pins source-file and compiler-bundle SHA256 values before any unit is accepted.

### SkillRL identity witness

```bash
git clone https://github.com/aiming-lab/SkillRL.git external/SkillRL
git -C external/SkillRL checkout 8e66726ed866a4e0a7f053586a41022798192e6c
python -m research_pipeline.asset_first_skillrl_representation_invariance \
  --contract protocols/skillrl-representation-invariance-contract.json \
  --output outputs/skillrl-regeneration.json
```

The protocol is zero-GPU/zero-model-call and preflights the pinned author files before probing fresh-ID exact-content clones.

## Claim boundary

This package supports the submission's narrow claims: released control-plane representation sensitivity, the exact finite-support equalizability criterion `R*(A)`, and the non-equalizable-support-geometry boundary. It does **not** establish downstream utility harm, dynamic STRI success, empirical SQC success, or LP algorithmic novelty. The Qwen3 pilot is included only for transparent qualification accounting and cannot support or refute dynamic STRI.


## Qualified SkillRL final-policy boundary receipt

The paper's optional C4 boundary result is included as `artifacts/asset-first-stri-skillrl-final-policy-p0e-supplement-receipt-20260817.json` together with its frozen anonymous contract and panel; the receipt content-addresses the internal model manifest without packaging author-local paths. The sanitized receipt records 18/24 competence calibration success, 24 paired A/B/C/D units with 18/24 terminal success in every arm and zero endpoint disagreements, B/C action-trajectory disagreement of 11/24 versus 15/24, exact D-to-A restoration, and the post-negative statistical-resolution audit. It supports only a qualified realization STOP. It does not establish population-level absence of a downstream effect, a persistent principle dead end, or an active recovery mechanism, and it does not alter N1--N3.


## Reviewer-requested certificate extensions

`artifacts/asset-first-stri-reviewer-extensions-20260819.json` records the exact LP dual, max-share-constrained certificate, exhaustive single-support-edge perturbation audit, and per-tool exact LP analysis used in the revised manuscript. These analyses are deterministic over the packaged frozen support matrices. The one-cell perturbation audit is a finite local sensitivity analysis, not a claim that learned support labels are calibrated or that arbitrary multi-cell support error is harmless.


## Released Skill-SP controller audit

`artifacts/asset-first-stri-released-controller-clone-audit-20260819.json` is the content-addressed receipt for the sampler/prompt-mixture audit. The audit code and unit tests are packaged under `research_pipeline/`. The third-party Skill-SP repository is intentionally not copied into this supplement. To rerun the first-party audit end-to-end, obtain the author release at the exact commit recorded in the receipt and run the packaged audit against the packaged `data/skillsp-toolcall-membership.jsonl`. The receipt records that a same-content clone yields the identical author questioner message string while the released ID-normalized sampler changes message-class mixture TV to 7/120; quotient-conserved class mass restores prompt-mixture and exposure TV to zero. This is a controller-input-distribution result, not downstream utility evidence.


## AutoSkill P19 dynamic behavioral propagation

The packaged qualification, frozen v2 contract, Stage-3 plan, final result, and 18-run manifest record the bounded four-arm AutoSkill P19 experiment used in the revised manuscript. The result is 6/6 original, 0/6 split4, 3/3 ID-placebo, and 3/3 quotient-control destructive post-checkout signatures with 18/18 valid fresh-container executions and one-sided Fisher p=0.0010822510822510823. The run manifest content-addresses every per-run receipt and trajectory; its packaged byte hash and canonical semantic hash are checked during supplement refresh. This supports only a representation-to-retrieval-to-executed-behavior consequence on one archived P19 substrate under a common executor. It does not establish task utility, longitudinal regret, end-to-end AutoSkill runtime behavior, or general AutoSkill safety.


## AutoSkill P19 matched mediator isolation

The first mediator-isolation attempt exposed a measurement operationalization bug: the command-local signature missed a destructive payload written to an intermediate script and copied to the post-checkout hook in a later command. The sequence-aware repair preserves all 18 Stage-3 labels exactly. All v1 runs are excluded from v2 inference. In six fresh v2 runs under the same split representation and matched five-slot/three-semantic-class injection, adding back the crowded-out post-checkout skill restores the mechanical destructive behavior in 3/3 runs, while adding a matched stale-output cleanup skill yields 0/3. The exact one-sided Fisher probability is 1/20=0.05. This isolates the post-checkout skill as the mediator within the one archived P19 substrate; it does not establish task utility, longitudinal regret, end-to-end AutoSkill behavior, or general safety.


## Structural robustness enrichment

The revised main-paper robustness panel is reproduced from the packaged frozen Skill-SP Level-1 membership matrix without model calls or GPU execution. `artifacts/asset-first-stri-target-null-analysis-20260824.json` records seven representation-independent tool-frequency target rays, nine feasible max-share constraints, and 200 degree-preserving bipartite rewires; all tested cases remain residual and every rewire has neutral `R*=2`. `artifacts/asset-first-stri-witness-peeling-20260824.json` records 22 successive pairwise-disjoint three-row dual witnesses spanning 19 tools before the peeled remainder becomes equalizable. `artifacts/asset-first-stri-support-edit-radius-20260824.json` solves exact addition-only and deletion-only MILPs: at least 22 support additions or 71 deletions are required to make the frozen neutral target equalizable, with MIP gap zero and independent `R*` verification. `reproduce.py` recomputes these results from the packaged membership data; the stored artifacts are provenance receipts, not substitutes for reproduction. These controls do not validate learned support, mixed-edit robustness, downstream utility, or a broader dynamic STRI claim.


## Experimental breadth and practical baselines

`artifacts/asset-first-stri-practical-baselines-20260824.json` evaluates uniform, inverse-coverage, NNLS, cover, max--min, and exact package weighting across five frozen regimes and freezes calibration weights before tool-disjoint heldout evaluation. `artifacts/asset-first-stri-crossval-sparsity-20260824.json` adds eight leave-one-tool-out no-refit transfers and exact active-package sparsity frontiers. `reproduce.py` recomputes both suites from packaged Skill-SP/logical data. The SkillRL budget artifact sweeps eight `top_k` values with fresh-dynamic-ID, non-dynamic-ID placebo, exact quotient, and capacity controls on the pinned first-party release. The SkillRouter artifact audits the released 75-query expert relevance graph as an external relevance analogue only; relevance is not executable semantic support. The SkillsBench qualification artifact records why task-local skill availability is not promoted to an exact support matrix: 79/87 tasks disagree with `required_skills` metadata and 75/87 `required_skills` lists are empty despite non-empty local skill directories. SkillRL, SkillRouter, and SkillsBench repositories are intentionally not redistributed and their receipts bind exact author commits/file hashes. No new model or GPU calls are used by these breadth analyses.
