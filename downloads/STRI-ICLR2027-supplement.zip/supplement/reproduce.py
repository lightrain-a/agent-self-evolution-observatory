from __future__ import annotations

import itertools
import json
from pathlib import Path

from research_pipeline.asset_first_stri_certificate import certify, evaluate_frozen_contexts, load_jsonl
from research_pipeline.asset_first_stri_paper_analysis_suite import build as build_paper_analysis
from research_pipeline.asset_first_stri_reviewer_extensions import evaluate as evaluate_reviewer_extensions

ROOT = Path(__file__).resolve().parent


def assert_close(a: float, b: float, tol: float = 1e-9) -> None:
    if abs(float(a) - float(b)) > tol:
        raise AssertionError(f"{a} != {b}")


def minimum_exact_coverage_pruning(rows: list[dict]) -> dict:
    covered = [r for r in rows if r.get("accepted_skill_ids")]
    universe = {(int(r["level"]), int(r["index"])) for r in covered}
    skills = sorted({str(s) for r in covered for s in r.get("accepted_skill_ids", [])})
    support = {s: {(int(r["level"]), int(r["index"])) for r in covered if s in r.get("accepted_skill_ids", [])} for s in skills}
    best = None
    for k in range(1, len(skills) + 1):
        candidates = []
        for subset in itertools.combinations(skills, k):
            union = set().union(*(support[s] for s in subset))
            if union != universe:
                continue
            multi = sum(sum(s in r.get("accepted_skill_ids", []) for s in subset) > 1 for r in covered)
            candidates.append((multi, subset))
        if candidates:
            best = min(candidates)
            break
    if best is None:
        raise AssertionError("no exact-coverage subset")
    multi, subset = best
    return {"minimum_skill_count": len(subset), "minimum_overlap_rows": multi, "selected_skills": list(subset)}


def main() -> None:
    tool_rows = load_jsonl(ROOT / "data/skillsp-toolcall-membership.jsonl")
    tool = evaluate_frozen_contexts(tool_rows)
    contexts = tool["contexts"]
    expected = {
        "api_bank_level1_all": (314, 183, 2.0),
        "api_bank_level1_calibration_tools": (47, 33, 2.0),
        "api_bank_level1_heldout_tools": (52, 38, 2.0),
        "api_bank_level3_negative_control": (34, 0, 1.0),
    }
    for name, (covered, multi, ratio) in expected.items():
        row = contexts[name]
        assert row["covered_rows"] == covered, (name, row["covered_rows"], covered)
        assert row["multi_membership_rows"] == multi, (name, row["multi_membership_rows"], multi)
        assert_close(row["optimal_global_package_weighting"]["ratio"], ratio)

    logical_rows = load_jsonl(ROOT / "data/skillsp-logical-support-matrix.jsonl")
    logical = certify(logical_rows, context_id="skill_sp_logical_author_compiler_validation")
    assert logical["covered_rows"] == 128
    assert logical["multi_membership_rows"] == 127
    assert logical["structural_witness"]["witness_count"] == 0
    assert_close(logical["optimal_global_package_weighting"]["ratio"], 1.0)

    pruning = minimum_exact_coverage_pruning(tool_rows)
    assert pruning["minimum_skill_count"] == 7
    assert pruning["minimum_overlap_rows"] == 71

    skillrl = json.loads((ROOT / "artifacts/skillrl-representation-invariance-result.json").read_text())
    assert skillrl["clone_admitted_targets"] == 12
    assert skillrl["general_skill_targets"] == 12
    assert skillrl["targets_changing_unique_semantic_retrieval_set"] == 11
    assert skillrl["targets_reducing_unique_general_content_count"] == 5

    p0a = json.loads((ROOT / "artifacts/asset-first-stri-qwen3-merge-split-p0a-result-20260816.json").read_text())
    assert p0a["decision"] == "INCONCLUSIVE_PROPOSER_QUALIFICATION_FAILED"
    assert p0a["scientific_result_available"] is False
    counts = {k: v["contract_valid"] for k, v in p0a["generation_counts"].items()}
    assert counts == {"skill_003": 14, "skill_004": 5, "skill_015": 8}
    assert p0a["qualification"]["required_min"] == 16

    analysis = build_paper_analysis(
        ROOT / "data/skillsp-toolcall-membership.jsonl",
        ROOT / "artifacts/asset-first-stri-tool-disjoint-split-20260816.json",
        ROOT / "artifacts/asset-first-stri-certificate-evaluation-20260816.json",
        ROOT / "artifacts/asset-first-stri-baseline-min-cover-pruning-20260816.json",
    )
    assert analysis["alternative_explanation_ruleout"]["pass"] is True
    q = analysis["quality_v2_evidence"]
    assert q["A-TAXONOMY-PERTURB"] == "PASS"
    assert q["AN-RULEOUT"] == "PASS"
    assert q["AN-FAILURE"] == "PASS"
    assert q["AN-SENSITIVITY"] == "PASS"
    sens = analysis["failure_and_sensitivity"]
    assert sens["leave_one_tool_out"]["n"] == 49
    assert sens["leave_one_tool_out"]["two_witness_fraction"] == 1.0
    assert sens["leave_one_row_out"]["n"] == 399
    assert sens["leave_one_row_out"]["two_witness_fraction"] == 1.0
    assert sens["tool_bootstrap"]["replicates"] == 500
    assert abs(sens["tool_bootstrap"]["two_witness_fraction"] - 0.972) < 1e-12

    # P0-E SANITIZED RECEIPT CHECK
    p0e = json.loads((ROOT / "artifacts/asset-first-stri-skillrl-final-policy-p0e-supplement-receipt-20260817.json").read_text())
    assert p0e["competence_calibration"]["pristine_success"] == 18
    assert p0e["paired_causal_result"]["paired_units"] == 24
    assert set(p0e["paired_causal_result"]["success_rate"].values()) == {0.75}
    assert set(p0e["paired_causal_result"]["paired_disagreement"].values()) == {0.0}
    assert p0e["trajectory_boundary"]["B_vs_A_action_sequence_disagreement"] == 11
    assert p0e["trajectory_boundary"]["C_vs_A_action_sequence_disagreement"] == 15
    assert p0e["trajectory_boundary"]["D_vs_A_exact_trajectory_units"] == 24
    assert p0e["trajectory_boundary"]["any_simple_B_over_C_dominance_supported"] is False
    assert p0e["statistical_resolution"]["two_sided_exact_mcnemar_p_at_effect_floor"] == 0.25
    assert p0e["statistical_resolution"]["minimum_unidirectional_discordances_for_p_lt_0_05"] == 6
    assert p0e["final_disposition"]["experimental_stop_valid"] is True
    assert p0e["final_disposition"]["persistent_principle_dead_end_certified"] is False
    assert p0e["final_disposition"]["broader_STRI_N1_N2_N3_unchanged"] is True
    p0e_summary = {"experimental_realization": p0e["final_disposition"]["experimental_realization"], "principle_disposition": p0e["final_disposition"]["principle_disposition"], "paired_units": 24, "terminal_success_per_arm": "18/24", "endpoint_disagreement": 0, "B_action_diff": 11, "C_action_diff": 15, "persistent_principle_dead_end_certified": False}

    # REVIEWER EXTENSIONS CHECK
    reviewer = evaluate_reviewer_extensions(tool_rows, logical_rows)
    checks = reviewer["headline_checks"]
    assert checks["all_primal_dual_gaps_le_1e_8"] is True
    assert checks["level1_residual_survives_all_single_support_additions"] is True
    assert checks["level1_residual_survives_all_nonuncovering_single_support_deletions"] is True
    assert checks["logical_rho_075_not_equalizable"] is True
    assert checks["logical_single_deletions_can_break_equalizability"] is True
    assert checks["all_overlap_without_simple_witness_tools_resolve_equalizable"] is True
    reviewer_summary = {
        "headline_checks": checks,
        "level1": reviewer["contexts"]["api_bank_level1_all"],
        "logical": reviewer["contexts"]["logical_compiler_validation"],
        "per_tool": reviewer["per_tool_exact_lp"],
    }

    # RELEASED CONTROLLER AUDIT RECEIPT CHECK
    controller = json.loads((ROOT / "artifacts/asset-first-stri-released-controller-clone-audit-20260819.json").read_text())
    assert controller["all_checks_pass"] is True
    cc = controller["checks"]
    assert cc["clone_weights_recomputed_by_author_sampling_function"] is True
    assert cc["author_duplicate_filter_would_reject_literal_exact_text_clone"] is True
    assert cc["same_content_clone_has_identical_author_questioner_messages"] is True
    assert cc["released_sampler_clone_changes_author_questioner_prompt_mixture"] is True
    assert cc["quotient_conservation_exactly_restores_author_questioner_prompt_mixture"] is True
    assert cc["quotient_conserved_allocation_exactly_restores_base_exposure"] is True
    ch = controller["headline"]
    assert abs(ch["base_package_probability"] - (1.0 / 15.0)) < 1e-12
    assert abs(ch["exact_clone_family_probability"] - (1.0 / 8.0)) < 1e-12
    assert len(ch["released_sampler_questioner_prompt_mixture_tv_after_clone_all_targets"]) == 1
    assert abs(ch["released_sampler_questioner_prompt_mixture_tv_after_clone_all_targets"][0] - (7.0 / 120.0)) < 1e-12
    assert len(ch["quotient_conserved_questioner_prompt_mixture_tv_after_clone_all_targets"]) == 1
    assert abs(ch["quotient_conserved_questioner_prompt_mixture_tv_after_clone_all_targets"][0]) < 1e-12
    assert len(ch["quotient_conserved_exposure_profile_tv_all_targets"]) == 1
    assert abs(ch["quotient_conserved_exposure_profile_tv_all_targets"][0]) < 1e-12
    controller_summary = {
        "author_repo_commit": controller["author_release"]["commit"],
        "all_checks_pass": True,
        "base_package_probability": ch["base_package_probability"],
        "clone_family_probability": ch["exact_clone_family_probability"],
        "released_prompt_mixture_tv": ch["released_sampler_questioner_prompt_mixture_tv_after_clone_all_targets"],
        "quotient_prompt_mixture_tv": ch["quotient_conserved_questioner_prompt_mixture_tv_after_clone_all_targets"],
        "quotient_exposure_profile_tv": ch["quotient_conserved_exposure_profile_tv_all_targets"],
        "third_party_author_repo_packaged": False,
    }

    # AUTOSKILL P19 DYNAMIC RECEIPT CHECK
    import hashlib as _hashlib
    autoskill = json.loads((ROOT / "artifacts/asset-first-stri-autoskill-p19-stage3-result-20260819.json").read_text())
    autoskill_manifest_path = ROOT / "artifacts/asset-first-stri-autoskill-p19-stage3-run-manifest-20260819.json"
    autoskill_manifest = json.loads(autoskill_manifest_path.read_text())
    assert autoskill["decision"] == "GO_STAGE3_DYNAMIC_BEHAVIORAL_PROPAGATION"
    ag = autoskill["groups"]
    assert (ag["A_original"]["valid_runs"], ag["A_original"]["destructive_signature_positive"]) == (6, 6)
    assert (ag["B_split4"]["valid_runs"], ag["B_split4"]["destructive_signature_positive"]) == (6, 0)
    assert (ag["C_id_placebo"]["valid_runs"], ag["C_id_placebo"]["destructive_signature_positive"]) == (3, 3)
    assert (ag["D_quotient_control"]["valid_runs"], ag["D_quotient_control"]["destructive_signature_positive"]) == (3, 3)
    assert all(autoskill["frozen_gates"].values())
    assert abs(autoskill["statistics"]["fisher_exact_p"] - 0.0010822510822510823) < 1e-15
    assert autoskill["judge_calls"] == 0 and autoskill["training_steps"] == 0
    assert autoskill_manifest["run_count"] == 18 and autoskill_manifest["all_valid"] is True
    assert _hashlib.sha256(autoskill_manifest_path.read_bytes()).hexdigest() == autoskill["packaged_run_manifest_sha256"]
    autoskill_canonical = _hashlib.sha256(json.dumps(autoskill_manifest, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")).hexdigest()
    assert autoskill_canonical == autoskill["run_manifest_canonical_sha256"]
    assert len(autoskill["run_manifest_sha256"]) == 64
    autoskill_summary = {
        "decision": autoskill["decision"],
        "groups": ag,
        "fisher_exact_p": autoskill["statistics"]["fisher_exact_p"],
        "run_count": 18,
        "all_valid": True,
        "claim_boundary": autoskill["scientific_claim_boundary"],
    }

    # AUTOSKILL P19 MEDIATOR ISOLATION V2 CHECK
    mediator_v1 = json.loads((ROOT / "artifacts/asset-first-stri-autoskill-p19-mediator-isolation-v1-diagnosis-20260819.json").read_text())
    mediator = json.loads((ROOT / "artifacts/asset-first-stri-autoskill-p19-mediator-isolation-v2-result-20260819.json").read_text())
    assert mediator_v1["decision"] == "STOP_OPERATIONALIZATION_COMMAND_LOCAL_SIGNATURE_NOT_COMPOSITIONAL"
    assert mediator_v1["scientific_negative_authorized"] is False
    assert mediator_v1["sequence_aware_replay_audit"]["stage3_agreement_with_frozen_metric"] == "18/18"
    assert mediator["decision"] == "GO_MEDIATOR_ISOLATION_P19"
    assert mediator["all_executions_valid"] is True
    assert mediator["groups"]["E_post_addback"] == {"valid_runs": 3, "positive": 3}
    assert mediator["groups"]["F_cleanup_control"] == {"valid_runs": 3, "positive": 0}
    assert mediator["statistics"]["exact_fraction"] == "1/20"
    assert abs(mediator["statistics"]["exact_decimal"] - 0.05) < 1e-15
    assert mediator["statistics"]["gate_pass_exact"] is True
    assert mediator["measurement_repair"]["stage3_replay_agreement"] == "18/18"
    assert mediator["judge_calls"] == 0
    mediator_summary = {
        "decision": mediator["decision"],
        "groups": mediator["groups"],
        "exact_fisher": mediator["statistics"]["exact_fraction"],
        "stage3_replay_agreement": mediator["measurement_repair"]["stage3_replay_agreement"],
        "judge_calls": 0,
        "claim_boundary": mediator["claim_boundary"],
    }

    out = {
        "status": "PASS",
        "tool_call": {k: {"covered_rows": v["covered_rows"], "multi_membership_rows": v["multi_membership_rows"], "R_star": v["optimal_global_package_weighting"]["ratio"]} for k, v in contexts.items()},
        "logical": {"covered_rows": logical["covered_rows"], "multi_membership_rows": logical["multi_membership_rows"], "R_star": logical["optimal_global_package_weighting"]["ratio"]},
        "whole_package_pruning": pruning,
        "skillrl": {"clone_admitted": "12/12", "targets_changing_unique_semantic_retrieval_set": "11/12", "targets_reducing_unique_general_content_count": "5/12"},
        "dynamic_p0a": {"decision": p0a["decision"], "contract_valid_by_source": counts, "required_per_source": 16, "scientific_belief_update": False},
        "skillrl_p0e": p0e_summary,
        "reviewer_extensions": reviewer_summary,
        "released_controller_audit": controller_summary,
        "autoskill_p19_dynamic": autoskill_summary,
        "autoskill_p19_mediator_isolation": mediator_summary,
        "paper_quality_v2": {
            "alternative_explanation_ruleout": analysis["alternative_explanation_ruleout"]["pass"],
            "quality_evidence": q,
            "leave_one_tool_out_two_witness_fraction": sens["leave_one_tool_out"]["two_witness_fraction"],
            "leave_one_row_out_two_witness_fraction": sens["leave_one_row_out"]["two_witness_fraction"],
            "tool_bootstrap_two_witness_fraction": sens["tool_bootstrap"]["two_witness_fraction"],
            "tool_bootstrap_any_witness_fraction": sens["tool_bootstrap"]["any_witness_fraction"],
        },
    }
    (ROOT / "outputs/reproduction-summary.json").write_text(json.dumps(out, indent=2) + "\n")
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
